import 'package:flutter/material.dart';
import 'package:growcery/account.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_switch/flutter_switch.dart';

class notifi extends StatefulWidget {
  const notifi({Key? key}) : super(key: key);

  @override
  State<notifi> createState() => _notifiState();
}

class _notifiState extends State<notifi> {
  bool light = true;
  bool light_a = true;
  bool noti = false;
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: notifire.spleshscreenprimerycolor,
        automaticallyImplyLeading: false,
        elevation: 0,
        toolbarHeight: 50,
        actions: [
          Row(children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return account();
                  },
                ));
              },
              child: Container(
                margin:
                    EdgeInsets.only(top: 8, right: 10,left: 10, bottom: 20),
                height: 8,
                width: 10,
                child: Icon(Icons.arrow_back,
                    size: 20, color: notifire.textshscreenprimerycolor),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 110, right: 130, top: 8, bottom: 10),
              child: Center(
                child: Text(
                  "Notification",
                  style: TextStyle(
                      fontSize: 14,
                      color: notifire.textshscreenprimerycolor,
                      fontFamily: "AirbnbCereal_W_Bd"),
                ),
              ),
            ),
          ]),
        ],
      ),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.only(top: 10),
            height: 50,
            width: 375,
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, top: 10, bottom: 10),
                  height: 30,
                  width: 250,
                  child: Text(
                    "App Notification",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 14,
                        color: notifire.textshscreenprimerycolor),
                  ),
                ),

                Container(
                  margin: EdgeInsets.only(top: 5,bottom: 15),
                    height: 30,
                    width: 50,
                    child: FlutterSwitch(
                        borderRadius: 15,
                        activeColor: Color(0xff00AB67),
                        height: 30,
                        width: 50,
                        activeToggleColor: Colors.white,
                        value: light,
                        onToggle: (value) {
                          setState(() {
                            light = value;
                          });
                        }))
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 8),
            height: 50,
            width: 375,
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, top: 10, bottom: 10),
                  height: 30,
                  width: 250,
                  child: Text(
                    "Email Notification",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 14,
                        color: notifire.textshscreenprimerycolor),
                  ),
                ),

                Container(
                    margin: EdgeInsets.only(top: 5,bottom: 15),
                    height: 30,
                    width: 50,
                    child: FlutterSwitch(
                        borderRadius: 15,
                        activeColor: Color(0xff00AB67),
                        height: 30,
                        width: 50,
                        activeToggleColor: Colors.white,
                        value: light_a,
                        onToggle: (value) {
                          setState(() {
                            light_a = value;
                          });
                        }))
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top:8),
            height: 50,
            width: 375,
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, top: 10, bottom: 10),
                  height: 30,
                  width: 250,
                  child: Text(
                    "SMS Notification",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 14,
                        color: notifire.textshscreenprimerycolor),
                  ),
                ),

                Container(
                    margin: EdgeInsets.only(top: 5,bottom: 15),
                    height: 30,
                    width: 50,
                    child: FlutterSwitch(
                        borderRadius: 15,
                        activeColor: Color(0xff00AB67),
                        height: 30,
                        width: 50,
                        activeToggleColor: Colors.white,
                        value: noti,
                        onToggle: (value) {
                          setState(() {
                            noti = value;
                          });
                        }))
              ],
            ),
          )
        ],
      ),
    );
  }
}
