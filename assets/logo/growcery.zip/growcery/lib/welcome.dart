import 'package:flutter/material.dart';
import 'package:growcery/create_easy.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class welcome extends StatefulWidget {
  const welcome({Key? key}) : super(key: key);

  @override
  State<welcome> createState() => _welcomeState();
}

class _welcomeState extends State<welcome> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }
  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
        backgroundColor: notifire.spleshscreenprimerycolor,

      //  backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: 380,
                width: 392,
                child: Image.asset(
                  "assets/Frame .png",
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 100, right: 100),
                    height: 50,
                    width: 150,
                    child: Center(
                        child: Text("Welcome to",
                            style: TextStyle(
                                fontSize: 20, color: notifire.textshscreenprimerycolor,fontFamily: "AirbnbCereal_W_Bd"))),
                  )
                ],
              ),
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 80, right: 80),
                    height: 50,
                    width: 240,
                    child: Center(
                        child: Text("Growcery",
                            style: TextStyle(
                                fontSize: 40,
                                color: Color(0xff00AB67),
                                fontFamily: "AirbnbCereal_W_Bd"))),
                  )
                ],
              ),
              SizedBox(
                height: 33,
              ),
              Column(
                children: [
                  Container(
                    height: 30,
                    width: 350,
                    //color: Colors.green,
                    child: Center(
                      child: Text(
                        "Lorem ipsum dolor sit amet, consectetur ",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Bk",
                            color: Color(0xff808080),
                            fontSize: 16),
                      ),
                    ),
                  )
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 30,
                    width: 300,
                    //color: Colors.green,
                    child: Center(
                      child: Text("adipiscing elit, sed do elusmod.",
                          style: TextStyle(
                              fontSize: 16,
                              color: Color(0xff808080),
                              fontFamily: "AirbnbCereal_W_Bk")),
                    ),
                  )
                ],
              ),

              SizedBox(height: 100),
              Column(
                children: [
                  InkWell(onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                      return create_easy();
                    },));
                  },
                    child:
                    Container(
                      height: 45,
                      width: 280,
                      decoration: BoxDecoration(
                          color: Color(0xff00AB67),
                       // color: Colors.green,
                          borderRadius: BorderRadius.circular(20)),
                      child: Center(
                          child: Text(
                        "Get started",
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            fontFamily: "AirbnbCereal_W_Bd"),
                      )),
                    ),
                    ),

                ],
              )
            ],
          ),
        ));
  }
}
