import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:growcery/splesh_screen.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => Colornotifire(),
        )
      ],
      child: MaterialApp(
        home: splesh_screen(),
        debugShowCheckedModeBanner: false,
      )));
}
