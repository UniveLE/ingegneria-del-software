import 'package:flutter/material.dart';
import 'package:growcery/login.dart';
import 'package:growcery/otp.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class login_num extends StatefulWidget {
  const login_num({Key? key}) : super(key: key);

  @override
  State<login_num> createState() => _login_numState();
}

class _login_numState extends State<login_num> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: notifire.spleshscreenprimerycolor,
        // toolbarHeight: 80,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context, MaterialPageRoute(
              builder: (context) {
                return login();
              },
            ));
          },
          child: Container(
            margin: EdgeInsets.only(top: 8, left: 20, bottom: 8),
            height: 15,
            width: 12,
            child: Icon(
              Icons.arrow_back,
              color: notifire.iconscreenprimerycolor,
            ),
          ),
        ),
        elevation: 0,
      ),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(left: 15, right: 260),
              child: Text(
                "Login",
                style: TextStyle(
                    fontFamily: "AirbnbCereal_W_Bd",
                    color: notifire.textshscreenprimerycolor,
                    fontSize: 24),
              ),
            ),
            SizedBox(height: 60,),
            Container(
              margin: EdgeInsets.only(right: 28,left: 28),
              height: 60,
              width: 319,
              child: Text(
                "join to Growcery for lorem dolor sit amet consectetur adisipisicing elit.",
                style: TextStyle(fontSize: 14,fontFamily: "AirbnbCereal_W_Bd",color: notifire.mintextscreenprimerycolor),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              margin: EdgeInsets.only(right: 120),
              width: 200,
              child: Text(
                "Phone Number",
                style: TextStyle(
                    fontSize: 12,
                    color: notifire.mintextscreenprimerycolor,
                    fontFamily: "AirbnbCereal_W_Bd"),
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 12),
                height: 60,
                width: 319,
                decoration: BoxDecoration(
                    color: Color(0xffFAFAFA),
                    borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 10), child: Text("")),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 48,
                      width: 230,
                      child: TextField(
                        decoration: InputDecoration(
                          disabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          hintText: "Phone Number",

                          //  labelText: "user name"
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: 330,),
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return otp();
              },));
            },child:
            Container(
              height: 60,
              width: 319,
              decoration: BoxDecoration(
                  color: Color(0xff00AB67),
                  // color: Colors.green,
                  borderRadius: BorderRadius.circular(20)),
              child: Center(
                  child: Text(
                    "Login",
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontFamily: "AirbnbCereal_W_Bd"),
                  )),
            ),
            )
          ],
        ),
      ),
    );
  }
}
