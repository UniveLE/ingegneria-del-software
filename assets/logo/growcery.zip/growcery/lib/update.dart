import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class update extends StatefulWidget {
  const update({Key? key}) : super(key: key);

  @override
  State<update> createState() => _updateState();
}

class _updateState extends State<update> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }
  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(children: [
          Container(
            height: 60,
              width: MediaQuery.of(context).size.width,
            color: notifire.topscreenprimerycolor,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 8, bottom: 8, left: 28),
                    height: 40,
                    width: 55,
                    decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(20)),
                    child: Center(
                      child: Text(
                        "All",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: Colors.white,
                            fontSize: 12),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 8, bottom: 8, left: 16),
                    height: 40,
                    width: 107,
                    decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.black12, width: 2)),
                    child: Center(
                      child: Text(
                        "Informastion",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.mintextscreenprimerycolor,
                            fontSize: 12),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 8, bottom: 8, left: 16),
                    height: 40,
                    width: 77,
                    decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.black12, width: 2)),
                    child: Center(
                      child: Text(
                        "Promo",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.mintextscreenprimerycolor,
                            fontSize: 12),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 8, bottom: 8, left: 16),
                    height: 40,
                    width: 107,
                    decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.black12, width: 2)),
                    child: Center(
                      child: Text(
                        "Activity",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.mintextscreenprimerycolor,
                            fontSize: 12),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Column(
            children: [
              Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 28, left: 28),
                    height: 15,
                    width: 41,
                    decoration: BoxDecoration(
                        color: Color(0xff00AB67).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Center(
                      child: Text(
                        "PROMO",
                        style: TextStyle(fontSize: 8, color: Color(0xff00AB67)),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 13, top: 28),
                    height: 20,
                    width: 70,
                    child: Center(
                      child: Text(
                        "An hour ago",
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: "AirbnbCereal_W_Bd.",
                            color: notifire.mintextscreenprimerycolor,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 168, top: 28, right: 20),
                    height: 12,
                    width: 12,
                    child: Image.asset("assets/logo/round.png"),
                  )
                ],
              )
            ],
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 20, left: 28, right: 28),
                height: 30,
                width: 319,
                color: notifire.spleshscreenprimerycolor,
                child: Text(
                  "Congrats! you got 10% off for all product",
                  style: TextStyle(
                      fontSize: 14,
                      fontFamily: "AirbnbCereal_W_Bd",
                      color: notifire.textshscreenprimerycolor),
                ),
              )
            ],
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 5, left: 28, right: 28),
                height: 40,
                width: 319,
                color: notifire.spleshscreenprimerycolor,
                child: Text(
                    "Wuzzah, have a nice hopping experince! Please check the expired date of the voucher.",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: notifire.mintextscreenprimerycolor)),
              )
            ],
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 20, left: 28, right: 28),
                height: 150,
                width: 319,
                child: Image.asset("assets/Coupon.png"),
              )
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: 13),
            height: 2,
            color: notifire.topscreenprimerycolor,
          ),
          Column(
            children: [
              Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 13, left: 28),
                    height: 15,
                    width: 60,
                    decoration: BoxDecoration(
                        color: Color(0xff00AB67).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Center(
                      child: Text(
                        "INFORMATION",
                        style: TextStyle(fontSize: 8, color: Color(0xff00AB67)),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 13, top: 13),
                    height: 20,
                    width: 90,
                    child: Center(
                      child: Text(
                        "Today, 10:00 AM",
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: "AirbnbCereal_W_Bd.",
                            color: notifire.mintextscreenprimerycolor,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 20, left: 28, right: 28),
                height: 30,
                width: 319,
                color: notifire.spleshscreenprimerycolor,
                child: Text(
                  "Your favorite items is available",
                  style: TextStyle(
                      fontSize: 14,
                      fontFamily: "AirbnbCereal_W_Bd",
                      color: notifire.textshscreenprimerycolor),
                ),
              )
            ],
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 5, left: 28, right: 28),
                height: 40,
                width: 319,
                color: notifire.spleshscreenprimerycolor,
                child: Text(
                    "Hey, special for you! Your favorite items is back."
                    "Check it out before runs out!",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: notifire.mintextscreenprimerycolor)),
              )
            ],
          ),
          Column(
            children: [
              Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 20, left: 28),
                    height: 67,
                    width: 67,
                    child: Image.asset("assets/fruit_1.png"),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, left: 16),
                    height: 67,
                    width: 67,
                    child: Image.asset("assets/Fruit_2.png"),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, left: 16),
                    height: 67,
                    width: 67,
                    child: Image.asset("assets/fruit_3.png"),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 20, left: 16),
                    height: 67,
                    width: 67,
                    child: Image.asset("assets/fruit_4.png"),
                  ),
                ],
              )
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: 13),
            height: 2,
            color: notifire.topscreenprimerycolor,
          ),
          Column(
            children: [
              Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 13, left: 28),
                    height: 15,
                    width: 45,
                    decoration: BoxDecoration(
                        color: Color(0xff00AB67).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Center(
                      child: Text(
                        "EVENT",
                        style: TextStyle(fontSize: 8, color: Color(0xff00AB67)),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 13, top: 13),
                    height: 20,
                    width: 120,
                    child: Center(
                      child: Text(
                        "Yesterday, 9:23 PM",
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: "AirbnbCereal_W_Bd.",
                            color: notifire.mintextscreenprimerycolor,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 20, left: 28, right: 28),
                height: 40,
                width: 319,
                color: notifire.spleshscreenprimerycolor,
                child: Text(
                  "Get 20% off your first order. This offer ends in a week, let’s get this!",
                  style: TextStyle(
                      fontSize: 14,
                      fontFamily: "AirbnbCereal_W_Bd",
                      color: notifire.textshscreenprimerycolor),
                ),
              )
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: 20, left: 28, right: 28, bottom: 20),
            height: 40,
            width: 300,
            decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: notifire.topscreenprimerycolor)),
            child: Row(
              children: [
                Container(
                  margin:
                      EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 7),
                  height: 20,
                  width: 210,
                  child: Text("PROMOCODE",
                      style: TextStyle(
                          fontSize: 12,
                          fontFamily: "AirbnbCereal_W_Md",
                          color: Colors.black)),
                ),
                IconButton(
                    onPressed: () {
                      FlutterClipboard.copy('PROMOCODE').then((value) =>
                          Fluttertoast.showToast(
                              msg: "copied",
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.CENTER,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              fontSize: 16.0));
                    },
                    icon: Icon(Icons.copy)),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
