import 'package:flutter/material.dart';
import 'package:growcery/account.dart';
import 'package:growcery/edit_pro.dart';
import 'package:growcery/password.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class profile extends StatefulWidget {
  const profile({Key? key}) : super(key: key);

  @override
  State<profile> createState() => _profileState();
}

class _profileState extends State<profile> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }
  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: notifire.spleshscreenprimerycolor,
        automaticallyImplyLeading: false,
        elevation: 0,
        toolbarHeight: 50,
        actions: [
          Row(children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return account();
                  },
                ));
              },
              child:
           Container(
                margin:
                    EdgeInsets.only(top: 8, right: 10,left: 5, bottom: 20),
                height: 8,
                width: 10,
                child:Icon(Icons.arrow_back,
                    size: 20, color: notifire.textshscreenprimerycolor),
              ),
            ),
            Container(
              margin: EdgeInsets.only(right: 120,left: 80, top: 8, bottom: 10),
              child: Center(
                child: Text(
                  "Profile & Security ",
                  style: TextStyle(
                      fontSize: 14,
                      color: notifire.textshscreenprimerycolor,
                      fontFamily: "AirbnbCereal_W_Bd"),
                ),
              ),
            ),
          ]),
        ],
      ),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: Column(children: [
        Container(
          height: 330,
          width: 375,
                child: ListView(children: [
                   InkWell(
                     onTap:() {
                       Navigator.push(context, MaterialPageRoute(builder: (context) {
                         return edit_pro();
                       },));
                     },
                     child: ListTile(
                      title: Container(
                        margin: EdgeInsets.only(top: 14, left: 9),
                        child: Text("Edit Profile",
                            style: TextStyle(
                                fontFamily: "AirbnbCereal_W_Md",
                                fontSize: 14,
                                color: notifire.textshscreenprimerycolor)),
                      ),
                      trailing: Container(
                        margin: EdgeInsets.only(top: 18),
                        child: Icon(
                          Icons.chevron_right_outlined,
                          color: notifire.textshscreenprimerycolor,
                        ),
                      ),
                  ),
                   ),
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return password();
              },));
            },
              child: ListTile(
                  title: Container(
                    margin: EdgeInsets.only(left: 9),
                    child: Text("Change Password",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            fontSize: 14,
                            color: notifire.textshscreenprimerycolor)),
                  ),
                  trailing: Container(margin: EdgeInsets.only(top: 5),
                    child: Icon(
                      Icons.chevron_right_outlined,
                      color: notifire.textshscreenprimerycolor,
                    ),
                  ),
              ),
            ),
            ListTile(
                title: Container(
                  margin: EdgeInsets.only(left: 9),
                  child: Text("PIN",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 14,
                          color: notifire.textshscreenprimerycolor)),
                ),
                trailing: Container(margin: EdgeInsets.only(top: 5),
                  child: Icon(
                    Icons.chevron_right_outlined,
                    color: notifire.textshscreenprimerycolor,
                  ),
                ),
            ),
            ListTile(
                title: Container(
                  margin: EdgeInsets.only(left: 9),
                  child: Text("2FA Verification",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 14,
                          color: notifire.textshscreenprimerycolor)),
                ),
                trailing: Container(
                  margin: EdgeInsets.only(top: 5),
                  child: Icon(
                    Icons.chevron_right_outlined,
                    color: notifire.textshscreenprimerycolor,
                  ),
                ),
            ),
            ListTile(
                title: Container(
                  margin: EdgeInsets.only(left: 9),
                  child: Text("Deactivate Account",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 14,
                          color: notifire.textshscreenprimerycolor)),
                ),
                trailing: Container(
                  margin: EdgeInsets.only(top:5),
                  child: Icon(
                    Icons.chevron_right_outlined,
                    color: notifire.textshscreenprimerycolor,
                  ),
                ),
            ),
            ListTile(
                title: Container(
                  margin: EdgeInsets.only(left: 9),
                  child: Text("Log Out",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 14,
                          color: notifire.textshscreenprimerycolor)),
                ),
                trailing: Container(
                  margin: EdgeInsets.only(top:5),
                  child: Icon(
                    Icons.chevron_right_outlined,
                    color: notifire.textshscreenprimerycolor,
                  ),
                ),
            ),
      ],),
              ),
    ]),
    );
  }
}
