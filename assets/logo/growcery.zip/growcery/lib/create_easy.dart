import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:growcery/login.dart';
import 'package:growcery/register.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class create_easy extends StatefulWidget {
  const create_easy({Key? key}) : super(key: key);

  @override
  State<create_easy> createState() => _create_easyState();
}

class _create_easyState extends State<create_easy> {
  bool status = false;
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
      backgroundColor: notifire.spleshscreenprimerycolor,
      bottomNavigationBar: Container(
        height: 180,
        width: 300,
        child: Column(
          children: [
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return register();
              },));
            },
              child: Container(
                height: 60,
                width: 319,
                decoration: BoxDecoration(
                    color: Color(0xff00AB67),
                    // color: Colors.green,
                    borderRadius: BorderRadius.circular(20)),
                child: Center(
                    child: Text(
                  "Create account",
                  style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                      fontFamily: "AirbnbCereal_W_Bd"),
                )),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return login();
              },));
            },child:
            Container(
              child: Text("Login to Your Account",
                  style: TextStyle(
                      fontSize: 14,
                      fontFamily: "AirbnbCereal_W_Bd",
                      color: notifire.mintextscreenprimerycolor)),
            ),
            )
          ],
        ),
      ),

      //backgroundColor: Colors.white,
      body: Container(
        child: PageView.builder(
          itemBuilder: (context, index) {
            return PageView(
              children: [
                Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 80, right: 50, left: 50),
                      height: 50,
                      width: 250,
                      //color: Colors.green,
                      child: Center(
                          child: Text("Easy Shopping",
                              style: TextStyle(
                                  fontFamily: "AirbnbCereal_W_Bd",
                                  color: notifire.textshscreenprimerycolor,
                                  fontSize: 24))),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Column(
                      children: [
                        Container(
                          height: 30,
                          width: 350,
                          //color: Colors.green,
                          child: Center(
                            child: Text(
                              "Lorem ipsum dolor sit amet, consectetur ",
                              style: TextStyle(
                                  fontFamily: "AirbnbCereal_W_Bk",
                                  color: notifire.mintextscreenprimerycolor,
                                  fontSize: 16),
                            ),
                          ),
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          height: 30,
                          width: 300,
                          //color: Colors.green,
                          child: Center(
                            child: Text("adipiscing elit, sed do elusmod.",
                                style: TextStyle(
                                    fontSize: 16,
                                    color: notifire.mintextscreenprimerycolor,
                                    fontFamily: "AirbnbCereal_W_Bk")),
                          ),
                        ),
                        Container(
                          height: 297,
                          width: 268,
                          child: Image.asset("assets/slide1.png"),
                        ),
                        SizedBox(
                          height: 35,
                        ),
                        Container(
                          height: 8,
                          width: 46,
                          child: Image.asset("assets/logo/slide_1.png"),
                        ),
                      ],
                    ),
                    // SizedBox(height: 10,),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 80, right: 50, left: 50),
                      height: 50,
                      width: 250,
                      //color: Colors.green,
                      child: Center(
                          child: Text("Get Discount & Offer",
                              style: TextStyle(
                                  fontFamily: "AirbnbCereal_W_Bd",
                                  color: notifire.textshscreenprimerycolor,
                                  fontSize: 24))),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Column(
                      children: [
                        Container(
                          height: 30,
                          width: 350,
                          //color: Colors.green,
                          child: Center(
                            child: Text(
                              "Ut adim adminim veniam, quis nostrud",
                              style: TextStyle(
                                  fontFamily: "AirbnbCereal_W_Bk",
                                  color: notifire.mintextscreenprimerycolor,
                                  fontSize: 16),
                            ),
                          ),
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          height: 30,
                          width: 300,
                          //color: Colors.green,
                          child: Center(
                            child: Text("exercitation ullamco laboris.",
                                style: TextStyle(
                                    fontSize: 16,
                                    color: notifire.mintextscreenprimerycolor,
                                    fontFamily: "AirbnbCereal_W_Bk")),
                          ),
                        ),
                        Container(
                          height: 297,
                          width: 268,
                          child: Image.asset("assets/slide2.png"),
                        ),
                        SizedBox(
                          height: 35,
                        ),
                        Container(
                          height: 8,
                          width: 46,
                          child: Image.asset("assets/logo/slide_2.png"),
                        ),
                      ],
                    ),
                    // SizedBox(height: 10,),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 80, right: 50, left: 50),
                      height: 50,
                      width: 250,
                      //color: Colors.green,
                      child: Center(
                          child: Text("Free & Quick Delivery",
                              style: TextStyle(
                                  fontFamily: "AirbnbCereal_W_Bd",
                                  color: notifire.textshscreenprimerycolor,
                                  fontSize: 24))),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Column(
                      children: [
                        Container(
                          height: 30,
                          width: 350,
                          //color: Colors.green,
                          child: Center(
                            child: Text(
                              "Luis aute irure dolor in reprehenderit in",
                              style: TextStyle(
                                  fontFamily: "AirbnbCereal_W_Bk",
                                  color: notifire.mintextscreenprimerycolor,
                                  fontSize: 16),
                            ),
                          ),
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          height: 30,
                          width: 300,
                          //color: Colors.green,
                          child: Center(
                            child: Text("voluptate velit esse cillum dolore.",
                                style: TextStyle(
                                    fontSize: 16,
                                    color: notifire.mintextscreenprimerycolor,
                                    fontFamily: "AirbnbCereal_W_Bk")),
                          ),
                        ),
                        Container(
                          height: 297,
                          width: 268,
                          child: Image.asset("assets/slide3.png"),
                        ),
                        SizedBox(
                          height: 35,
                        ),
                        Container(
                          height: 8,
                          width: 46,
                          child: Image.asset("assets/logo/slide_3.png"),
                        ),
                      ],
                    ),
                    // SizedBox(height: 10,),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
