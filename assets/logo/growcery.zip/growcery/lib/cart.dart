import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:growcery/account.dart';
import 'package:growcery/all.dart';
import 'package:growcery/artichoke.dart';
import 'package:growcery/favurite.dart';
import 'package:growcery/foryou.dart';
import 'package:growcery/home.dart';
import 'package:growcery/order.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class cart extends StatefulWidget {
  const cart({Key? key}) : super(key: key);

  @override
  State<cart> createState() => _cartState();
}

class _cartState extends State<cart> with SingleTickerProviderStateMixin {
  List<String> slide = [
    "assets/logo/slide_1.png",
    "assets/logo/slide_2.png",
    "assets/logo/slide_3.png"
  ];
  late Colornotifire notifire;
  List<List1> ditails = [
    List1(
        image1: "assets/cabbage.png",
        name1: "Cabbage",
        name2: "Approx 6oz",
        name3: "\$3.49",
        name4: "\$5.98"),
    List1(
        image1: "assets/orrange.png",
        name1: "Mandarin",
        name2: "4ct, approx 2lb",
        name3: "\$2.99",
        name4: "\$5.98"),
    List1(
        image1: "assets/stew.png",
        name1: "Beef Chuck Stew",
        name2: "12-14ct/lb",
        name3: "\$7.99",
        name4: "\$15.98"),
  ];
  List<List4> ditails3 = [
    List4(
        image1: "assets/kiwi.png",
        name1: "Kiwifruit",
        name2: "approx 0.25lb",
        name3: "\$0.89"),
    List4(
        image1: "assets/cobbage1.png",
        name1: "Cobbage",
        name2: "approx 2lb",
        name3: "\$3.49"),
    List4(
        image1: "assets/crad.png",
        name1: "Crab",
        name2: "6ct | \$4.50/ct",
        name3: "\$26.9"),
    List4(
        image1: "assets/almond.png",
        name1: "Almond",
        name2: "16oz | \$8.99/lb",
        name3: "\$8.99"),
    List4(
        image1: "assets/pasta.png",
        name1: "Pasta",
        name2: "19oz | \$4.91/lb",
        name3: "\$3.49"),
    List4(
        image1: "assets/beef.png",
        name1: "Beef Chuck Stew",
        name2: "12 - 14ct/lb",
        name3: "\$26.99"),
  ];
  int cnt = 0;
  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  List<Widget> tab = [
    const all(),
    const foryou(),
    const artichoke(),
  ];

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  void _incrementcount() {
    setState(() {
      cnt++;
    });
  }

  void _dicrementcount() {
    setState(() {
      if (cnt > 0) {
        cnt--;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
      bottomNavigationBar: Container(
        height: 80,
        width: 380,
        child: Row(
          children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return home();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 33, top: 18, right: 31),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/home1.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 25, top: 7, left: 25),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Home",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return order();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 35, top: 18, right: 38),
                    height: 18,
                    width: 18,
                    child: Image.asset("assets/logo/order.png",
                        color: notifire.mintextscreenprimerycolor),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 7, left: 21, right: 20),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Order",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 18, left: 30, right: 30),
                  height: 18,
                  width: 18,
                  child: Image.asset("assets/logo/cart.png",
                      color: Color(0xff00AB67)),
                ),
                Container(
                  margin: EdgeInsets.only(left: 12, top: 7),
                  height: 12,
                  width: 35,
                  child: Text(
                    "Cart",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: Color(0xff00AB67)),
                  ),
                )
              ],
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return account();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 18, left: 35, right: 20),
                    height: 18,
                    width: 18,
                    child: Image.asset("assets/logo/account1.png",
                        color: notifire.mintextscreenprimerycolor),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 35, top: 7, right: 20),
                    height: 12,
                    width: 50,
                    child: Text(
                      "Account",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.mintextscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
      appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: notifire.spleshscreenprimerycolor,
          elevation: 0,
          actions: [
            Column(
              children: [
                Row(children: [
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(right: 125, top: 10, left: 28),
                      height: 40,
                      width: 120,
                      child: Text("Cart",
                          style: TextStyle(
                              color: notifire.textshscreenprimerycolor,
                              fontFamily: "AirbnbCereal_W_Bd",
                              fontSize: 24)),
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.only(right: 23),
                      height: 16,
                      width: 16,
                      child: Image.asset(
                        "assets/logo/search_1.png",
                        color: notifire.textshscreenprimerycolor,
                      )),
                  InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return favurite();
                        },
                      ));
                    },
                    child: Container(
                      margin: EdgeInsets.only(right: 30),
                      height: 15,
                      width: 16,
                      child: Image.asset(
                        "assets/logo/like.png",
                        color: notifire.textshscreenprimerycolor,
                      ),
                    ),
                  ),
                ]),
              ],
            ),
          ]),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 8),
                    height: 20,
                    width: 48,
                    child: Text(
                      "Send to:",
                      style: TextStyle(
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 8),
                    height: 20,
                    width: 110,
                    child: Text(
                      "854 Liberty Avenue",
                      style: TextStyle(
                          fontSize: 12,
                          fontFamily: "AirbnbCereal_W_Md",
                          color: notifire.textshscreenprimerycolor),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 6, bottom: 23),
                    // padding:
                    //     EdgeInsets.only(top: 7, bottom: 7, left: 6, right: 6),
                    height: 4,
                    width: 7,
                    child: Icon(Icons.keyboard_arrow_down_sharp,
                        color: notifire.mintextscreenprimerycolor),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 30),
              height: 10,
              width: MediaQuery.of(context).size.width,
              color: notifire.topscreenprimerycolor,
            ),
            Container(
              height: 380,
              width: double.infinity,
              child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: ditails.length,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: EdgeInsets.only(top: 10),
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  width: 2,
                                  color: notifire.topscreenprimerycolor))),
                      child: Slidable(
                        key: Key("${ditails}"),
                        endActionPane:
                            ActionPane(motion: ScrollMotion(), children: [
                          SlidableAction(
                            onPressed: (context) {
                              setState(() {
                                ditails.removeAt(index);
                              });
                            },
                            icon: Icons.delete,
                            backgroundColor: Colors.red,
                            label: "Remove List",
                          )
                        ]),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(top: 14, left: 28),
                                  height: 50,
                                  width: 50,
                                  child:
                                      Image.asset("${ditails[index].image1}"),
                                ),
                                Column(
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(
                                          top: 14, left: 16, right: 20),
                                      height: 20,
                                      width: 120,
                                      child: Text(
                                        "${ditails[index].name1}",
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontFamily: "AirbnbCereal_W_Md.otf",
                                            color: notifire
                                                .textshscreenprimerycolor),
                                      ),
                                    ),
                                    Container(
                                      margin:
                                          EdgeInsets.only(left: 16, right: 50),
                                      height: 15,
                                      width: 90,
                                      child: Text(
                                        "${ditails[index].name2}",
                                        style: TextStyle(
                                            color: notifire
                                                .mintextscreenprimerycolor,
                                            fontFamily: "AirbnbCereal_W_Bk",
                                            fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Container(
                                      margin:
                                          EdgeInsets.only(left: 30, top: 14),
                                      height: 30,
                                      width: 45,
                                      child: Text(
                                        "${ditails[index].name3}",
                                        style: TextStyle(
                                            fontSize: 16,
                                            color: notifire
                                                .textshscreenprimerycolor,
                                            fontFamily: "AirbnbCereal_W_Md"),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(right: 30),
                                      height: 20,
                                      width: 19,
                                      child: Text(
                                        "/ea",
                                        style: TextStyle(
                                            fontFamily: "AirbnbCereal_W_Bk",
                                            fontSize: 12,
                                            color: notifire
                                                .mintextscreenprimerycolor),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 28, top: 21),
                                  height: 30,
                                  width: 35,
                                  child: Text("Total:"),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 9, left: 5),
                                  height: 15,
                                  width: 45,
                                  child: Text("${ditails[index].name4}",
                                      style: TextStyle(
                                          fontFamily: "AirbnbCereal_W_Md",
                                          fontSize: 12,
                                          color: notifire
                                              .textshscreenprimerycolor)),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 9),
                                  width: 1,
                                  height: 15,
                                  child: Text(
                                    "|",
                                    style: TextStyle(
                                        fontSize: 12,
                                        color:
                                            notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(
                                      right: 51, top: 9, left: 10),
                                  height: 20,
                                  width: 67,
                                  child: Center(
                                    child: Text(
                                      "Write Notes",
                                      style: TextStyle(
                                          fontFamily: "AirbnbCereal_W_Bk",
                                          fontSize: 12,
                                          color: Color(0xff00AB67)),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    return setState(() {
                                      _dicrementcount();
                                    });
                                  },
                                  child: Container(
                                    height: 30,
                                    width: 30,
                                    child:
                                        Image.asset("assets/logo/mainas.png"),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Center(
                                      child: Text(
                                    "${cnt}",
                                    style: TextStyle(
                                        color:
                                            notifire.textshscreenprimerycolor),
                                  )),
                                ),
                                InkWell(
                                  onTap: () {
                                    return setState(() {
                                      _incrementcount();
                                    });
                                  },
                                  child: Container(
                                    height: 30,
                                    width: 30,
                                    child:
                                        Image.asset("assets/logo/plus_1.png"),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  }),
            ),
            Container(
              height: 10,
              width: MediaQuery.of(context).size.width,
              color: notifire.topscreenprimerycolor,
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, right: 260, top: 28),
                  height: 30,
                  width: 68,
                  child: Text(
                    "Discover",
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: "AirbnbCereal_W_Bd",
                        color: notifire.textshscreenprimerycolor),
                  ),
                )
              ],
            ),
            Column(children: [
              Container(
                margin: EdgeInsets.only(left: 28, top: 20, right: 28),
                height: 40,
                width: 300,
                decoration: BoxDecoration(
                  color: notifire.spleshscreenprimerycolor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: TabBar(controller: _tabController, tabs: [
                  Tab(
                      child: Text(
                    "all",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: notifire.mintextscreenprimerycolor),
                  )),
                  Tab(
                      child: Text(
                    "For You",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: notifire.mintextscreenprimerycolor),
                  )),
                  Tab(
                      child: Text(
                    "artichoke",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: notifire.mintextscreenprimerycolor),
                  ))
                ]),
              ),
              Container(
                  height: 690,
                  child: TabBarView(controller: _tabController, children: tab)),
            ]),
            Container(
              height: 10,
              width: MediaQuery.of(context).size.width,
              color: notifire.topscreenprimerycolor,
            ),
            Card(
              margin: EdgeInsets.only(top: 28, left: 28, right: 28),
              child: Container(
                height: 60,
                width: 319,
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      width: 1, color: notifire.topscreenprimerycolor),
                ),
                child: Row(children: [
                  Container(
                    margin: EdgeInsets.only(left: 15, top: 15, bottom: 15),
                    padding:
                        EdgeInsets.only(left: 10, top: 5, bottom: 5, right: 9),
                    height: 30,
                    width: 30,
                    decoration: BoxDecoration(
                        color: Color(0xff00AB67).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12)),
                    child: Image.asset("assets/logo/percantage.png"),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 16),
                    height: 30,
                    width: 172,
                    child: Center(
                      child: Text(
                        "Apply promotional code",
                        style: TextStyle(
                            fontSize: 14,
                            fontFamily: "AirbnbCereal_W_Bd",
                            color: notifire.textshscreenprimerycolor),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 35),
                    child: Icon(
                      Icons.keyboard_arrow_right_sharp,
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                ]),
              ),
            ),
            Container(
              height: 90,
              width: 375,
              child: Row(
                children: [
                  Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 28, top: 20, right: 120),
                        height: 20,
                        width: 60,
                        child: Text(
                          "Price Total",
                          style: TextStyle(
                              fontFamily: "AirbnbCereal_W_Md",
                              color: notifire.mintextscreenprimerycolor,
                              fontSize: 12),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 28, right: 120),
                        height: 30,
                        width: 63,
                        child: Text(
                          "\$25.45",
                          style: TextStyle(
                              fontSize: 18,
                              fontFamily: "AirbnbCereal_W_Md",
                              color: notifire.textshscreenprimerycolor),
                        ),
                      )
                    ],
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 28),
                    height: 50,
                    width: 117,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: Color(0xff00AB67)),
                    child: Center(
                      child: Text(
                        "Checkout",
                        style: TextStyle(
                            fontSize: 12,
                            fontFamily: "AirbnbCereal_W_Bk",
                            color: Colors.white),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class List1 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;
  String? name4;

  List1({this.image1, this.name1, this.name2, this.name3, this.name4});
}

class List4 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List4({this.image1, this.name1, this.name2, this.name3});
}
