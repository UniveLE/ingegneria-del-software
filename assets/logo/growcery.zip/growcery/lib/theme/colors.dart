import 'package:flutter/material.dart';
Color PrimeryColor = Colors.black87;
Color darkPrimeryColor = Colors.white;

//dark text color
Color textprimeryColor = Colors.white;
Color textdarkprimeryColor = Colors.black87;

//light text color
Color mintextprimeryColor = Colors.white60;
Color mintextdarkprimeryColor = Colors.black45;

//icon color
Color iconprimeryColor = Colors.white;
Color icondarkprimeryColor = Colors.black87;

//terms box
Color termsprimeryColor = Colors.white;
Color termsdarkprimeryColor = Colors.black;

//skip
Color skipprimeryColor = Colors.black;
Color skipdarkprimeryColor = Colors.white;

//top screen
Color topscreemprimeryColor = Colors.grey.shade900;
Color topscreendarkprimeryColor = Colors.grey.shade100;

