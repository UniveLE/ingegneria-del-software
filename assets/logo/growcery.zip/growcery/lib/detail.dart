
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:growcery/home.dart';
import 'package:growcery/photo.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:growcery/vegetable.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:readmore/readmore.dart';

class detail extends StatefulWidget {
  List ditails;
  List<String> slide;
  var index;

  detail(this.ditails, this.index, this.slide);

  @override
  State<detail> createState() => _detailState();
}

class _detailState extends State<detail> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
        bottomNavigationBar: Row(
          children: [
            Container(
              height: 90,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 20, bottom: 20),
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            width: 1, color: notifire.topscreenprimerycolor)),
                    child: Container(
                        margin: EdgeInsets.all(12),
                        child: Image.asset(
                          "assets/logo/like.png",
                          color: notifire.textshscreenprimerycolor,
                        )),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 20, bottom: 20),
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            width: 1, color: notifire.topscreenprimerycolor)),
                    child: Container(
                        margin: EdgeInsets.all(12),
                        child: Image.asset(
                          "assets/logo/share.png",
                          color: notifire.textshscreenprimerycolor,
                        )),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20, right: 20),
                    height: 50,
                    width: 160,
                    decoration: BoxDecoration(
                        color: Color(0xff00AB67),
                        borderRadius: BorderRadius.circular(16)),
                    child: Center(
                        child: Text(
                      "Add to Cart",
                      style: TextStyle(
                          fontSize: 12,
                          fontFamily: "AirbnbCereal_W_Md",
                          color: notifire.textshscreenprimerycolor),
                    )),
                  )
                ],
              ),
            )
          ],
        ),
        appBar: AppBar(
          backgroundColor: Color(0xffF2FBF7),
          automaticallyImplyLeading: false,
          elevation: 0,
          toolbarHeight: 50,
          actions: [
            Row(children: [
              SizedBox(width: 17,),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return vegetable();
                    },
                  ));
                },
                child: Container(
                  margin:
                      EdgeInsets.only(top: 8, bottom: 20),
                  height: 8,
                //  width: 10,
                  child:
                      Icon(Icons.arrow_back, size: 20, color: Colors.black87),
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 80, top: 8,left: 90, bottom: 10),
                child: Center(
                  child: Text(
                    "Product Detail",
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                        fontFamily: "AirbnbCereal_W_Bd"),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 15, bottom: 5, left: 10),
                height: 40,
                width: 40,
                //    color: Colors.black,
                child: Stack(children: [
                  Container(
                    height: 16.5,
                    width: 16,
                    child: Image.asset(
                      "assets/logo/bag.png",
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 9,bottom: 15),
                    height: 12,
                    width: 12,
                    child: Image.asset("assets/logo/Badge_1.png"),
                  )
                ]),
              ),
            ]),
          ],
        ),
        backgroundColor: notifire.spleshscreenprimerycolor,
        body: SingleChildScrollView(
          child: Column(children: [
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return photo(widget.ditails,widget.index,widget.slide);
              },));
            },
              child: Container(
                height: 319,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: Color(0xffF2FBF7),
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10))),
                child: PageView.builder(
                    itemCount: widget.slide.length,
                    itemBuilder: (_, i) {
                      return Column(children: [
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 40, right: 20),
                              height: 270,
                              width: 270,
                              //color: Colors.blueAccent,
                              child: Image.asset(
                                  "${widget.ditails[widget.index].image1}"),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Center(
                              child: Container(
                                margin: EdgeInsets.only(left: 150, right: 100),
                                height: 8,
                                width: 46,
                                child: Image.asset(
                                  "${widget.slide[i]}",
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ]);
                    }),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 10,
              color: notifire.topscreenprimerycolor,
            ),
            Column(
              children: [
                Container(
                  height: 90,
                  width: 375,
                  child: Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 28),
                        height: 50,
                        width: 50,
                        child: Image.asset("assets/gf.png"),
                      ),
                      Column(
                        children: [
                          Container(
                            margin:
                                EdgeInsets.only(left: 15, top: 30, right: 129),
                            height: 20,
                            width: 95,
                            child: Text(
                              "GrowFarm Inc",
                              style: TextStyle(
                                  color: notifire.textshscreenprimerycolor,
                                  fontSize: 14,
                                  fontFamily: "AirbnbCereal_W_Bd"),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 15, right: 100),
                            height: 15,
                            width: 122,
                            child: Text(
                              "Downers Grove, Illiois",
                              style: TextStyle(
                                  color: notifire.mintextscreenprimerycolor,
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Bk"),
                            ),
                          ),
                        ],
                      ),
                      Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                            color: Color(0xffF2FBF7),
                            borderRadius: BorderRadius.circular(15)),
                        child: Icon(Icons.check_outlined,
                            color: Color(0xff00AB67)),
                      )
                    ],
                  ),
                )
              ],
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 10,
              color: notifire.topscreenprimerycolor,
            ),
            Column(children: [
              Container(
                height: 150,
                width: 375,
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 28, top: 28, right: 240),
                      height: 30,
                      width: 95,
                      child: Text(
                        "DESCRIPTION",
                        style: TextStyle(
                            fontSize: 14,
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor),
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 28, right: 28, top: 10),
                        child: ReadMoreText(
                          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod. ",
                          trimLines: 2,
                          style: TextStyle(
                              color: notifire.mintextscreenprimerycolor,
                              fontSize: 14),
                          colorClickableText: Colors.blue,
                          trimMode: TrimMode.Line,
                          trimCollapsedText: '...Read more',
                          trimExpandedText: ' Read less',
                        )),
                  ],
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: 10,
                color: notifire.topscreenprimerycolor,
              )
            ]),
            Column(
              children: [
                Container(
                  height: 131,
                  width: 375,
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 28, top: 28, right: 270),
                        height: 30,
                        width: 55,
                        child: Text(
                          "REVIEW",
                          style: TextStyle(
                              fontFamily: "AirbnbCereal_W_Md",
                              color: notifire.textshscreenprimerycolor,
                              fontSize: 14),
                        ),
                      ),
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(
                                left: 28, right: 23, top: 10, bottom: 40),
                            height: 20,
                            width: 100,
                            child: Row(
                              children: [
                                Container(
                                  height: 15,
                                  width: 15,
                                  child: Icon(
                                    Icons.star,
                                    color: Colors.yellow,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 5),
                                  height: 15,
                                  width: 15,
                                  child: Icon(
                                    Icons.star,
                                    color: Colors.yellow,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 5),
                                  height: 15,
                                  width: 15,
                                  child: Icon(
                                    Icons.star,
                                    color: Colors.yellow,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 5),
                                  height: 15,
                                  width: 15,
                                  child: Icon(
                                    Icons.star,
                                    color: Colors.yellow,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(left: 5),
                                  height: 15,
                                  width: 15,
                                  child: Icon(
                                    Icons.star,
                                    color: Colors.yellow,
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(right: 30, bottom: 10),
                            height: 30,
                            width: 127,
                            child: Text(
                              "5.0 from 496 buyer",
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: "AirbnbCereal_W_Bk",
                                  color: notifire.mintextscreenprimerycolor),
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.only(bottom: 25),
                              height: 10,
                              width: 6,
                              child: Icon(
                                Icons.arrow_forward_ios,
                                color: notifire.mintextscreenprimerycolor,
                                size: 15,
                              )),
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 10,
              color: notifire.topscreenprimerycolor,
            )
          ]),
        ));
  }
}
// class List1 {
//   String? image1;
//   String? name1;
//   String? name2;
//   String? name3;
//
//   List1({this.image1, this.name1, this.name2, this.name3});
// }
