import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:growcery/account.dart';
import 'package:growcery/all.dart';
import 'package:growcery/artichoke.dart';
import 'package:growcery/cart.dart';
import 'package:growcery/foryou.dart';
import 'package:growcery/notification.dart';
import 'package:growcery/order.dart';
import 'package:growcery/search.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:growcery/vegetable.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';

class home extends StatefulWidget {
  const home({Key? key}) : super(key: key);

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> with SingleTickerProviderStateMixin {
  List<String> slide = [
    "assets/logo/slide_1.png",
    "assets/logo/slide_2.png",
    "assets/logo/slide_3.png"
  ];
  bool status = false;
  int cnt = 0;
  List<List1> ditails = [
    List1(
        image1: "assets/crad.png",
        name1: "Crab",
        name2: "6ct | \$4.50/ct",
        name3: "\$26.99")
  ];
  List<List2> ditails1 = [
    List2(
        image1: "assets/bluebarry.png",
        name1: "Bluebarry",
        name2: "approx 2lb",
        name3: "\$2.99")
  ];
  List<List3> ditails2 = [
    List3(
        image1: "assets/cabbage.png",
        name1: "Cabbage",
        name2: "\$3.50 / 500g",
        name3: "\$0.80")
  ];
  List image = [
    "assets/promotion.png",
    "assets/promotion.png",
    "assets/promotion.png"
  ];
  List<List4> ditails3 = [
    List4(
        image1: "assets/kiwi.png",
        name1: "Kiwifruit",
        name2: "approx 0.25lb",
        name3: "\$0.89"),
    List4(
        image1: "assets/cobbage1.png",
        name1: "Cobbage",
        name2: "approx 2lb",
        name3: "\$3.49"),
    List4(
        image1: "assets/crad.png",
        name1: "Crab",
        name2: "6ct | \$4.50/ct",
        name3: "\$26.9"),
    List4(
        image1: "assets/almond.png",
        name1: "Almond",
        name2: "16oz | \$8.99/lb",
        name3: "\$8.99"),
    List4(
        image1: "assets/pasta.png",
        name1: "Pasta",
        name2: "19oz | \$4.91/lb",
        name3: "\$3.49"),
    List4(
        image1: "assets/beef.png",
        name1: "Beef Chuck Stew",
        name2: "12 - 14ct/lb",
        name3: "\$26.99"),
  ];
  late Colornotifire notifire;

  late TabController _tabController;

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  List<Widget> tab = [
    const all(),
    const foryou(),
    const artichoke(),
  ];

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  void _incrementcount() {
    setState(() {
      cnt++;
    });
  }

  void _dicrementcount() {
    setState(() {
      if (cnt > 0) {
        cnt--;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
      bottomNavigationBar: Container(
        height: 80,
        width: 380,
        child: Row(
          children: [
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 33, top: 18, right: 31),
                  height: 18,
                  width: 18,
                  child: Image.asset("assets/logo/home1.png"),
                ),
                Container(
                  margin: EdgeInsets.only(right: 25, top: 7, left: 25),
                  height: 12,
                  width: 35,
                  child: Text(
                    "Home",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: Color(0xff00AB67)),
                  ),
                )
              ],
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return order();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 35, top: 18, right: 38),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/order.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 7, left: 21, right: 20),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Order",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return cart();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 18, left: 30, right: 30),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/cart.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 12, top: 7),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Cart",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return account();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 18, left: 35, right: 20),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/account1.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 35, top: 7, right: 20),
                    height: 12,
                    width: 50,
                    child: Text(
                      "Account",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
      appBar: AppBar(
          iconTheme: IconThemeData(color: notifire.textshscreenprimerycolor),

          // automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: notifire.spleshscreenprimerycolor,
          actions: [
            Center(
              child: Container(
                margin: EdgeInsets.only(right: 30, left: 10),
                width: 120,
                child: Text("Growcery",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Bd",
                        fontSize: 24,
                        color: notifire.textshscreenprimerycolor)),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 7, bottom: 7, right: 5),
              height: 15,
              width: 100,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: notifire.topscreenprimerycolor)),
              child: Center(
                  child: Text(
                "Santa Ana,Ca",
                style: TextStyle(
                    color: notifire.textshscreenprimerycolor,
                    fontSize: 12,
                    fontFamily: "AirbnbCereal_W_Bd"),
              )),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 5, left: 20, bottom: 4, right: 10),
                //    color: notifire.spleshscreenprimerycolor,
                child: InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return notification();
                      },
                    ));
                  },
                  child: Stack(children: [
                    Container(
                      margin: EdgeInsets.only(top: 3),
                      height: 17,
                      width: 16,
                      child: Image.asset(
                        "assets/logo/notification.png",
                        color: notifire.textshscreenprimerycolor,
                        width: 17,
                        height: 16,
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 8, bottom: 10),
                      height: 12,
                      width: 12,
                      child: Image.asset("assets/Badge.png"),
                    )
                  ]),
                ),
              ),
            )
          ]),
      drawer: Drawer(
          child: Container(
              height: 100,
              width: 50,
              color: notifire.spleshscreenprimerycolor,
              child: SingleChildScrollView(
                  child: Column(children: [
                Row(children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(top: 60, left: 20, right: 75),
                      height: 12,
                      width: 12,
                      child: Image.asset(
                        "assets/logo/cansel.png",
                        fit: BoxFit.cover,
                        color: notifire.textshscreenprimerycolor,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 60, bottom: 7, right: 13),
                    height: 30,
                    width: 100,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: notifire.mintextscreenprimerycolor)),
                    child: Center(
                        child: Text(
                      "Santa Ana,Ca",
                      style: TextStyle(
                          color: notifire.textshscreenprimerycolor,
                          fontSize: 12,
                          fontFamily: "AirbnbCereal_W_Bd"),
                    )),
                  ),
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(
                          top: 60, left: 20, bottom: 4, right: 10),
                      //    color: notifire.spleshscreenprimerycolor,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(
                            builder: (context) {
                              return notification();
                            },
                          ));
                        },
                        child: Stack(children: [
                          Container(
                            margin: EdgeInsets.only(top: 3),
                            height: 17,
                            width: 16,
                            child: Image.asset(
                              "assets/logo/notification.png",
                              color: notifire.textshscreenprimerycolor,
                              width: 17,
                              height: 16,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 8, bottom: 10),
                            height: 12,
                            width: 12,
                            child: Image.asset("assets/Badge.png"),
                          )
                        ]),
                      ),
                    ),
                  )
                ]),
                Container(
                  margin: EdgeInsets.only(top: 25),
                  height: 80,
                  width: MediaQuery.of(context).size.width,
                  color: notifire.topscreenprimerycolor,
                  child: Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 28, top: 15, bottom: 15),
                        height: 50,
                        width: 50,
                        child: Image.asset("assets/pro_pic.png"),
                      ),
                      Column(
                        children: [
                          Container(
                            margin:
                                EdgeInsets.only(top: 15, left: 15, right: 30),
                            height: 30,
                            width: 128,
                            child: Text(
                              "Susan J. Patterson",
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: "AirbnbCereal_W_Bd",
                                  color: notifire.textshscreenprimerycolor),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 15, right: 80),
                            height: 20,
                            width: 73,
                            child: Text(
                              "@spatterson",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Bk",
                                  color: notifire.mintextscreenprimerycolor),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 10, right: 80),
                  height: 480,
                  width: 300,
                  child: ListView(children: [
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/invite.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "Invite Friend",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/rate.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "Rate This App",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/about.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "About Us",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/contact.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "Contact",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/faq.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "FAQ",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/terms.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "terms & Condition",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/help.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "Help Center",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                    ListTile(
                      leading: Image.asset(
                        "assets/logo/privecy.png",
                        height: 20,
                        width: 20,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                      title: Text(
                        "Privacy Policy",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    )
                  ]),
                ),
                SizedBox(
                  height: 10,
                ),
                Transform.scale(
                  scale: 0.6,
                  child: LiteRollingSwitch(
                    iconOn: Icons.nightlight,
                    iconOff: Icons.sunny,
                    animationDuration: const Duration(milliseconds: 500),
                    textOn: 'Dark',
                    textOff: 'Light',
                    colorOn: const Color(0xff242424),
                    colorOff: const Color(0xff1F75EC),
                    value: status,
                    onChanged: (bool value) async {
                      setState(() {
                        status = value;
                      });
                      final prefs = await SharedPreferences.getInstance();
                      setState(
                        () {
                          notifire.setlsDark = value;
                          prefs.setBool("setIsDark", value);
                        },
                      );
                    },
                    onDoubleTap: () {},
                    onSwipe: () {},
                    onTap: () {},
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 20, right: 90),
                  height: 30,
                  width: 150,
                  child: Text(
                    "Change Language",
                    style: TextStyle(
                        fontSize: 14,
                        color: notifire.textshscreenprimerycolor,
                        fontFamily: "AirbnbCereal_W_Md"),
                  ),
                )
              ])))),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 20, left: 10),
              height: 50,
              width: 319,
              decoration: BoxDecoration(
                color: notifire.topscreenprimerycolor,
                borderRadius: BorderRadius.circular(15),
              ),
              child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return search();
                    },
                  ));
                },
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (context) {
                            return search();
                          },
                        ));
                      },
                      child: Container(
                          padding:
                              EdgeInsets.only(left: 15, top: 15, bottom: 15),
                          height: 50,
                          width: 200,
                          child: Text(
                            "Search anything",
                            style: TextStyle(
                                fontSize: 12,
                                fontFamily: "AirbnbCereal_W_Bk",
                                color: Colors.black45),
                          )),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 60),
                      child: Icon(Icons.search, color: Colors.black45),
                    )
                  ],
                ),
              ),
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, top: 28, right: 130),
                  height: 30,
                  width: 200,
                  child: Text(
                    "What are you looking for?",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Bd",
                        fontSize: 16,
                        color: notifire.textshscreenprimerycolor),
                  ),
                )
              ],
            ),
            Column(
              children: [
                Row(
                  children: [
                    Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 25, top: 20),
                          height: 60,
                          width: 60,
                          child: InkWell(
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(
                                builder: (context) {
                                  return vegetable();
                                },
                              ));
                            },
                            child: Image.asset(
                              "assets/vegeteble.png",
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 35, top: 12),
                          height: 20,
                          width: 60,
                          child: InkWell(
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(
                                builder: (context) {
                                  return vegetable();
                                },
                              ));
                            },
                            child: Text("vegetable",
                                style: TextStyle(
                                    fontSize: 12,
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor)),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 25, top: 28),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/meat.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 50, top: 12),
                          height: 20,
                          width: 50,
                          child: Text("Meat",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 20, right: 15, top: 20),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/fruit.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 35, top: 12),
                          height: 20,
                          width: 55,
                          child: Text("Fruit",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 15, right: 15, top: 28),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/frozen.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 30, top: 12),
                          height: 20,
                          width: 60,
                          child: Text("Frozen",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 20),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/sea_food.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 10, top: 12),
                          height: 20,
                          width: 60,
                          child: Text("Sea food",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 28),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/bread.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 20, top: 12),
                          height: 20,
                          width: 50,
                          child: Text("Bread",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        )
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 10, right: 10, top: 20),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/milk_egg.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 15, top: 12, right: 15),
                          height: 20,
                          width: 60,
                          child: Text("Milk & Egg",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 15, right: 10, top: 28),
                          height: 60,
                          width: 60,
                          child: Image.asset(
                            "assets/organic.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 20, top: 12, right: 10),
                          height: 20,
                          width: 60,
                          child: Text("Organic",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        )
                      ],
                    ),
                  ],
                )
              ],
            ),
            // Column(
            //   children: [
            //     Row(
            //       children: [
            //         Column(
            //           children: [
            //             Container(
            //               margin: EdgeInsets.only(left: 25, top: 28),
            //               height: 60,
            //               width: 60,
            //               child: Image.asset(
            //                 "assets/meat.png",
            //                 fit: BoxFit.cover,
            //               ),
            //             ),
            //             Container(
            //               margin: EdgeInsets.only(left: 50, top: 12),
            //               height: 20,
            //               width: 50,
            //               child: Text("Meat",
            //                   style: TextStyle(
            //                       fontSize: 12,
            //                       fontFamily: "AirbnbCereal_W_Md",
            //                       color: notifire.textshscreenprimerycolor)),
            //             )
            //           ],
            //         ),
            //         Column(
            //           children: [
            //             Container(
            //               margin: EdgeInsets.only(left: 15, right: 15, top: 28),
            //               height: 60,
            //               width: 60,
            //               child: Image.asset(
            //                 "assets/frozen.png",
            //                 fit: BoxFit.cover,
            //               ),
            //             ),
            //             Container(
            //               margin: EdgeInsets.only(left: 30, top: 12),
            //               height: 20,
            //               width: 60,
            //               child: Text("Frozen",
            //                   style: TextStyle(
            //                       fontSize: 12,
            //                       fontFamily: "AirbnbCereal_W_Md",
            //                       color: notifire.textshscreenprimerycolor)),
            //             )
            //           ],
            //         ),
            //         Column(
            //           children: [
            //             Container(
            //               margin: EdgeInsets.only(top: 28),
            //               height: 60,
            //               width: 60,
            //               child: Image.asset(
            //                 "assets/bread.png",
            //                 fit: BoxFit.cover,
            //               ),
            //             ),
            //             Container(
            //               margin: EdgeInsets.only(left: 15, top: 12),
            //               height: 20,
            //               width: 60,
            //               child: Text("Bread",
            //                   style: TextStyle(
            //                       fontSize: 12,
            //                       fontFamily: "AirbnbCereal_W_Md",
            //                       color: notifire.textshscreenprimerycolor)),
            //             )
            //           ],
            //         ),
            //         Column(
            //           children: [
            //             Container(
            //               margin: EdgeInsets.only(left: 15, right: 20, top: 28),
            //               height: 60,
            //               width: 60,
            //               child: Image.asset(
            //                 "assets/organic.png",
            //                 fit: BoxFit.cover,
            //               ),
            //             ),
            //             Container(
            //               margin: EdgeInsets.only(left: 15, top: 12, right: 15),
            //               height: 20,
            //               width: 60,
            //               child: Text("Organic",
            //                   style: TextStyle(
            //                       fontSize: 12,
            //                       fontFamily: "AirbnbCereal_W_Md",
            //                       color: notifire.textshscreenprimerycolor)),
            //             )
            //           ],
            //         ),

            Column(children: [
              Container(
                margin: EdgeInsets.only(left: 28, top: 35, right: 180),
                height: 30,
                width: 143,
                child: Text("Today's Promotion",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Bd",
                        color: notifire.textshscreenprimerycolor,
                        fontSize: 16)),
              ),
            ]),
            Container(
              height: 150,
              width: 319,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: image.length,
                itemBuilder: (context, index) {
                  return Row(
                    children: [
                      Container(
                          margin: EdgeInsets.only(right: 15),
                          child: Image.asset("${image[index]}"))
                    ],
                  );
                },
              ),
            ),

            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, right: 250, top: 28),
                  height: 30,
                  width: 75,
                  child: Text("Top Picks",
                      style: TextStyle(
                          fontSize: 16,
                          color: notifire.textshscreenprimerycolor,
                          fontFamily: "AirbnbCereal_W_Bd")),
                )
              ],
            ),
            //SingleChildScrollView(scrollDirection: Axis.horizontal),

            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28),
                    height: 240,
                    width: 152,
                    decoration: BoxDecoration(
                      color: Colors.pink.shade50.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: ditails.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16, right: 16),
                              height: 120,
                              width: 120,
                              child: Image.asset("${ditails[index].image1}"),
                            ),
                            Container(
                              margin:
                                  EdgeInsets.only(left: 16, right: 16, top: 6),
                              height: 30,
                              width: 120,
                              child: Text(
                                "${ditails[index].name1}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor,
                                    fontSize: 14),
                              ),
                            ),
                            Container(
                              height: 20,
                              width: 120,
                              child: Text(
                                "${ditails[index].name2}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Bk",
                                    color: notifire.mintextscreenprimerycolor,
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 16, top: 16),
                                  height: 30,
                                  width: 56,
                                  child: Text(
                                    "${ditails[index].name3}",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                            notifire.textshscreenprimerycolor,
                                        fontFamily: "AirbnbCereal_W_Md"),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 30),
                                  height: 20,
                                  width: 19,
                                  child: Text(
                                    "/ea",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Bk",
                                        fontSize: 12,
                                        color:
                                            notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Image.asset(
                                    "assets/plus.png",
                                    fit: BoxFit.cover,
                                  ),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 15),
                    height: 240,
                    width: 152,
                    decoration: BoxDecoration(
                      color: Colors.purple.shade50.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: ditails.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16, right: 16),
                              height: 120,
                              width: 120,
                              child: Image.asset("${ditails1[index].image1}"),
                            ),
                            Container(
                              margin:
                                  EdgeInsets.only(left: 16, right: 16, top: 6),
                              height: 30,
                              width: 120,
                              child: Text(
                                "${ditails1[index].name1}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor,
                                    fontSize: 14),
                              ),
                            ),
                            Container(
                              height: 20,
                              width: 120,
                              child: Text(
                                "${ditails1[index].name2}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Bk",
                                    color: notifire.mintextscreenprimerycolor,
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 16, top: 16),
                                  height: 30,
                                  width: 56,
                                  child: Text(
                                    "${ditails1[index].name3}",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                            notifire.textshscreenprimerycolor,
                                        fontFamily: "AirbnbCereal_W_Md"),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 30),
                                  height: 20,
                                  width: 19,
                                  child: Text(
                                    "/ea",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Bk",
                                        fontSize: 12,
                                        color:
                                            notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Image.asset(
                                    "assets/plus.png",
                                    fit: BoxFit.cover,
                                  ),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 15),
                    height: 240,
                    width: 152,
                    decoration: BoxDecoration(
                      color: Colors.green.shade50.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: ditails.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16, right: 16),
                              height: 120,
                              width: 120,
                              child: Image.asset("${ditails2[index].image1}"),
                            ),
                            Container(
                              margin:
                                  EdgeInsets.only(left: 16, right: 16, top: 6),
                              height: 30,
                              width: 120,
                              child: Text(
                                "${ditails2[index].name1}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor,
                                    fontSize: 14),
                              ),
                            ),
                            Container(
                              height: 20,
                              width: 120,
                              child: Text(
                                "${ditails2[index].name2}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Bk",
                                    color: notifire.mintextscreenprimerycolor,
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 16, top: 16),
                                  height: 30,
                                  width: 56,
                                  child: Text(
                                    "${ditails2[index].name3}",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                            notifire.textshscreenprimerycolor,
                                        fontFamily: "AirbnbCereal_W_Md"),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 30),
                                  height: 20,
                                  width: 19,
                                  child: Text(
                                    "/ea",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Bk",
                                        fontSize: 12,
                                        color:
                                            notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Image.asset(
                                    "assets/plus.png",
                                    fit: BoxFit.cover,
                                  ),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                  )
                ],
              ),
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, right: 260, top: 28),
                  height: 30,
                  width: 68,
                  child: Text(
                    "Discover",
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: "AirbnbCereal_W_Bd",
                        color: notifire.textshscreenprimerycolor),
                  ),
                )
              ],
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, top: 20,right: 28),
                  height: 40,
                  width: 300,
                  decoration: BoxDecoration(
                      color: notifire.spleshscreenprimerycolor,
                      borderRadius: BorderRadius.circular(20),),
                  child: TabBar(controller: _tabController, tabs: [
                    Tab(child: Text("all",style: TextStyle( fontFamily: "AirbnbCereal_W_Md",
                                   fontSize: 12,
                                   color: notifire.mintextscreenprimerycolor),)),
                    Tab(
                        child: Text("For You",style: TextStyle( fontFamily: "AirbnbCereal_W_Md",
                            fontSize: 12,
                            color: notifire.mintextscreenprimerycolor),)
                    ),
                    Tab(child: Text("artichoke",style: TextStyle( fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: notifire.mintextscreenprimerycolor),))
                  ]),
                ),
                Container(
                  height: 690,
                    child: TabBarView(controller: _tabController,
                        children:
                    tab
                    )),]
            ),
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: Column(
            //     children: [
            //       // give the tab bar a height [can change hheight to preferred height]
            //       Container(
            //         height: 45,
            //         decoration: BoxDecoration(
            //           color: Colors.grey[300],
            //           borderRadius: BorderRadius.circular(
            //             25.0,
            //           ),
            //         ),
            //         child:
            //         TabBar(
            //           controller: _tabController,
            //           // give the indicator a decoration (color and border radius)
            //           indicator: BoxDecoration(
            //             borderRadius: BorderRadius.circular(
            //               25.0,
            //             ),
            //             color: Colors.green,
            //           ),
            //           labelColor: Colors.white,
            //           unselectedLabelColor: Colors.black,
            //           tabs: [
            //             // first tab [you can add an icon using the icon property]
            //             Tab(
            //               text: 'Place Bid',
            //             ),
            //
            //             // second tab [you can add an icon using the icon property]
            //             Tab(
            //               text: 'Buy Now',
            //             ),
            //             Tab(text: 'artichoke',)
            //           ],
            //         ),
            //       ),
            //       // tab bar view here
            //       Expanded(
            //         child: TabBarView(
            //           controller: _tabController,
            //           children: [
            //             // first tab bar view widget
            //             Center(
            //               child: Text(
            //                 'Place Bid',
            //                 style: TextStyle(
            //                   fontSize: 25,
            //                   fontWeight: FontWeight.w600,
            //                 ),
            //               ),
            //             ),
            //
            //             // second tab bar view widget
            //             Center(
            //               child: Text(
            //                 'Buy Now',
            //                 style: TextStyle(
            //                   fontSize: 25,
            //                   fontWeight: FontWeight.w600,
            //                 ),
            //               ),
            //             ),
            //             Center(
            //               child: Text(
            //                 'artichoke',
            //                 style: TextStyle(
            //                   fontSize: 25,
            //                   fontWeight: FontWeight.w600,
            //                 ),
            //               ),
            //             ),
            //           ],
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // Container(
            //   margin: EdgeInsets.only(left: 28, top: 20),
            //   height: 40,
            //   width: 55,
            //   decoration: BoxDecoration(
            //       color: Colors.green,
            //       borderRadius: BorderRadius.circular(20)),
            //   child: Center(
            //     child: Text(
            //       "All",
            //       style: TextStyle(
            //           fontFamily: "AirbnbCereal_W_Md",
            //           fontSize: 12,
            //           color: Colors.white),
            //     ),
            //   ),
            // ),
            // Container(
            //   margin: EdgeInsets.only(left: 28, top: 20),
            //   height: 40,
            //   width: 85,
            //   decoration: BoxDecoration(
            //       color: notifire.spleshscreenprimerycolor,
            //       borderRadius: BorderRadius.circular(20),
            //       border: Border.all(
            //           color: notifire.topscreenprimerycolor,
            //           width: 1)),
            //   child: Center(
            //     child: Text(
            //       "For You",
            //       style: TextStyle(
            //           fontFamily: "AirbnbCereal_W_Md",
            //           fontSize: 12,
            //           color: notifire.mintextscreenprimerycolor),
            //     ),
            //   ),
            // ),
            // Container(
            //   margin: EdgeInsets.only(left: 28, top: 20),
            //   height: 40,
            //   width: 95,
            //   decoration: BoxDecoration(
            //       color: notifire.spleshscreenprimerycolor,
            //       borderRadius: BorderRadius.circular(20),
            //       border: Border.all(
            //           color: notifire.topscreenprimerycolor,
            //           width: 1)),
            //   child: Center(
            //     child: Text(
            //       "Artichoke",
            //       style: TextStyle(
            //           fontFamily: "AirbnbCereal_W_Md",
            //           fontSize: 12,
            //           color: notifire.mintextscreenprimerycolor),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}

class List1 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List1({this.image1, this.name1, this.name2, this.name3});
}

class List2 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List2({this.image1, this.name1, this.name2, this.name3});
}

class List3 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List3({this.image1, this.name1, this.name2, this.name3});
}

class List4 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List4({this.image1, this.name1, this.name2, this.name3});
}
