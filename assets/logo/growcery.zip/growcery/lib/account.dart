import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:growcery/cart.dart';
import 'package:growcery/favurite.dart';
import 'package:growcery/home.dart';
import 'package:growcery/notifi.dart';
import 'package:growcery/notification.dart';
import 'package:growcery/order.dart';
import 'package:growcery/payment.dart';
import 'package:growcery/profile.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class account extends StatefulWidget {
  const account({Key? key}) : super(key: key);

  @override
  State<account> createState() => _accountState();
}

class _accountState extends State<account> {
  List<List1> ditails = [
    List1(
        image1: "assets/crad.png",
        name1: "Crab",
        name2: "6ct | \$4.50/ct",
        name3: "\$26.99")
  ];
  List<List2> ditails1 = [
    List2(
        image1: "assets/bluebarry.png",
        name1: "Bluebarry",
        name2: "approx 2lb",
        name3: "\$2.99")
  ];
  List<List3> ditails2 = [
    List3(
        image1: "assets/cabbage.png",
        name1: "Cabbage",
        name2: "\$3.50 / 500g",
        name3: "\$0.80")
  ];
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
      bottomNavigationBar: Container(
        height: 80,
        width: 380,
        child: Row(
          children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return home();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 33, top: 18, right: 31),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/home1.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 25, top: 7, left: 25),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Home",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return order();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(
                      left: 35,
                      top: 18,
                      right: 38
                    ),
                    height: 18,
                    width: 18,
                    child: Image.asset("assets/logo/order.png",
                        color: notifire.mintextscreenprimerycolor),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 7,left: 21,right: 20),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Order",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return cart();
              },));
            },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 18, left: 30,right: 30),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/cart.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 12, top: 7),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Cart",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 18, left: 35,right: 20),
                  height: 18,
                  width: 18,
                  child: Image.asset(
                    "assets/logo/account1.png",
                    color: Color(0xff00AB67),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: 35, top: 7,right: 20),
                  height: 12,
                  width: 50,
                  child: Text(
                    "Account",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: Color(0xff00AB67)),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
      appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: notifire.spleshscreenprimerycolor,
          elevation: 0,
          actions: [
            Column(
              children: [
                Row(children: [
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(right: 138, top: 10, left: 28),
                      height: 40,
                      width: 120,
                      child: Text("Account",
                          style: TextStyle(
                              color: notifire.textshscreenprimerycolor,
                              fontFamily: "AirbnbCereal_W_Bd",
                              fontSize: 24)),
                    ),
                  ),
                  InkWell(onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) {
                      return favurite();
                    },));
                  },
                    child: Container(
                      height: 18,
                      width: 18,
                      child: Image.asset(
                        "assets/logo/like.png",
                        color: notifire.textshscreenprimerycolor,
                      ),
                    ),
                  ),
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(
                          top: 5, left: 20, bottom: 4, right: 10),
                      //    color: notifire.spleshscreenprimerycolor,
                      child: InkWell(onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return notification();
                        },));
                      },
                        child: Stack(children: [
                          Container(
                            margin: EdgeInsets.only(top: 3),
                            height: 17,
                            width: 16,
                            child: Image.asset(
                              "assets/logo/notification.png",
                              color: notifire.textshscreenprimerycolor,
                              width: 17,
                              height: 16,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(left: 8, bottom: 10),
                            height: 12,
                            width: 12,
                            child: Image.asset("assets/Badge.png"),
                          )
                        ]),
                      ),
                    ),
                  ),
                ]),
              ],
            ),
          ]),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 8, left: 28, right: 28),
              height: 282,
              width: 319,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      width: 1, color: notifire.topscreenprimerycolor)),
              child: Stack(
                children: [
                  Container(
                    height: 201,
                    width: 319,
                  ),
                  Positioned(
                      child: Container(
                    child: Image.asset("assets/frame.png"),
                  )),
                  Positioned(
                      left: 128,
                      top: 55,
                      right: 128,
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100)),
                        child: Image.asset("assets/pro_pic_1.png"),
                      )),
                  Positioned(
                    left: 80,
                    right: 79,
                    top: 121,
                    child: Container(
                      height: 30,
                      width: 146,
                      child: Text(
                        "Susan J. Patterson",
                        style: TextStyle(
                            fontSize: 16,
                            fontFamily: "AirbnbCereal_W_Bd",
                            color: notifire.textshscreenprimerycolor),
                      ),
                    ),
                  ),
                  Positioned(
                      right: 108,
                      top: 151,
                      left: 107,
                      child: Container(
                        height: 30,
                        width: 85,
                        child: Text(
                          "@spatterson",
                          style: TextStyle(
                              fontSize: 14,
                              fontFamily: "AirbnbCereal_W_Bk",
                              color: notifire.mintextscreenprimerycolor),
                        ),
                      )),
                  Positioned(
                      top: 200,
                      child: Container(
                        width: 319,
                        height: 1,
                        color: notifire.topscreenprimerycolor,
                      )),
                  Positioned(
                    left: 60,
                    top: 215,
                    child: Column(
                      children: [
                        Positioned(
                          child: Container(
                            height: 18,
                            width: 20,
                            child: Image.asset(
                              "assets/logo/order.png",
                              color: notifire.textshscreenprimerycolor,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Positioned(
                    top: 245,
                    left: 45,
                    child: Column(
                      children: [
                        Container(
                          height: 20,
                          width: 54,
                          child: Text("My Order",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 150,
                    top: 215,
                    child: Column(
                      children: [
                        Positioned(
                          child: Container(
                            height: 18,
                            width: 20,
                            child: Image.asset(
                              "assets/logo/voucher.png",
                              color: notifire.textshscreenprimerycolor,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Positioned(
                    top: 245,
                    left: 135,
                    child: Column(
                      children: [
                        Container(
                          height: 20,
                          width: 54,
                          child: Text("Voucher",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 241,
                    top: 215,
                    child: Column(
                      children: [
                        Positioned(
                          child: Container(
                            height: 18,
                            width: 20,
                            child: Image.asset(
                              "assets/logo/location.png",
                              color: notifire.textshscreenprimerycolor,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Positioned(
                    top: 245,
                    left: 225,
                    child: Column(
                      children: [
                        Container(
                          height: 20,
                          width: 54,
                          child: Text("Address",
                              style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: "AirbnbCereal_W_Md",
                                  color: notifire.textshscreenprimerycolor)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 28),
              height: 10,
              color: notifire.topscreenprimerycolor,
            ),
            Container(
              height: 330,
              width: 375,
              child:
                  ListView(physics: NeverScrollableScrollPhysics(), children: [
                InkWell(onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return profile();
                  },));
                },
                  child: ListTile(
                    leading: Container(
                        margin: EdgeInsets.only(left: 15, top: 14),
                        child: Image.asset(
                          "assets/logo/user.png",
                          height: 21,
                          width: 18,
                          color: notifire.mintextscreenprimerycolor,
                        )),
                    title: Container(
                      margin: EdgeInsets.only(top: 14, left: 9),
                      child: Text("Profile & Security",
                          style: TextStyle(
                              fontFamily: "AirbnbCereal_W_Bk",
                              fontSize: 14,
                              color: notifire.textshscreenprimerycolor)),
                    ),
                    trailing: Container(
                      margin: EdgeInsets.only(top: 18),
                      child: Icon(
                        Icons.chevron_right_outlined,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                    ),
                  ),
                ),
                InkWell(onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return payment();
                  },));
                },
                  child: ListTile(
                    leading: Container(
                        margin: EdgeInsets.only(left: 15),
                        child: Image.asset(
                          "assets/logo/finance.png",
                          height: 21,
                          width: 18,
                          color: notifire.mintextscreenprimerycolor,
                        )),
                    title: Container(
                      margin: EdgeInsets.only(left: 9),
                      child: Text("Payments Option",
                          style: TextStyle(
                              fontFamily: "AirbnbCereal_W_Bk",
                              fontSize: 14,
                              color: notifire.textshscreenprimerycolor)),
                    ),
                    trailing: Container(margin: EdgeInsets.only(top: 5),
                      child: Icon(
                        Icons.chevron_right_outlined,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                    ),
                  ),
                ),
                InkWell(onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return favurite();
                  },));
                },
                  child: ListTile(
                    leading: Container(
                        margin: EdgeInsets.only(left: 15),
                        child: Image.asset(
                          "assets/logo/like.png",
                          height: 21,
                          width: 18,
                          color: notifire.mintextscreenprimerycolor,
                        )),
                    title: Container(
                      margin: EdgeInsets.only(left: 9),
                      child: Text("Favorite List",
                          style: TextStyle(
                              fontFamily: "AirbnbCereal_W_Bk",
                              fontSize: 14,
                              color: notifire.textshscreenprimerycolor)),
                    ),
                    trailing: Container(margin: EdgeInsets.only(top: 5),
                      child: Icon(
                        Icons.chevron_right_outlined,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                    ),
                  ),
                ),
                InkWell(onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return notifi();
                  },));
                },
                  child: ListTile(
                    leading: Container(
                        margin: EdgeInsets.only(left: 15),
                        child: Image.asset(
                          "assets/logo/notification.png",
                          height: 21,
                          width: 18,
                          color: notifire.mintextscreenprimerycolor,
                        )),
                    title: Container(
                      margin: EdgeInsets.only(left: 9),
                      child: Text("Notifications",
                          style: TextStyle(
                              fontFamily: "AirbnbCereal_W_Bk",
                              fontSize: 14,
                              color: notifire.textshscreenprimerycolor)),
                    ),
                    trailing: Container(
                      margin: EdgeInsets.only(top: 5),
                      child: Icon(
                        Icons.chevron_right_outlined,
                        color: notifire.mintextscreenprimerycolor,
                      ),
                    ),
                  ),
                ),
                ListTile(
                  leading: Container(
                      margin: EdgeInsets.only(left: 15),
                      child: Image.asset(
                        "assets/logo/buissness.png",
                        height: 21,
                        width: 18,
                        color: notifire.mintextscreenprimerycolor,
                      )),
                  title: Container(
                    margin: EdgeInsets.only(left: 9),
                    child: Text("Help Center",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Bk",
                            fontSize: 14,
                            color: notifire.textshscreenprimerycolor)),
                  ),
                  trailing: Container(
                    margin: EdgeInsets.only(top:5),
                    child: Icon(
                      Icons.chevron_right_outlined,
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                ),
                ListTile(
                  leading: Container(
                      margin: EdgeInsets.only(left: 15),
                      child: Image.asset(
                        "assets/logo/editor.png",
                        height: 21,
                        width: 18,
                        color: notifire.mintextscreenprimerycolor,
                      )),
                  title: Container(
                    margin: EdgeInsets.only(left: 9),
                    child: Text("Change Language",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Bk",
                            fontSize: 14,
                            color: notifire.textshscreenprimerycolor)),
                  ),
                  trailing: Container(
                    margin: EdgeInsets.only(top:5),
                    child: Icon(
                      Icons.chevron_right_outlined,
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                ),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 28),
              height: 10,
              color: notifire.topscreenprimerycolor,
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, right: 200, top: 28),
                  height: 30,
                  width: 135,
                  child: Text("Your Last Order",
                      style: TextStyle(
                          fontSize: 16,
                          color: notifire.textshscreenprimerycolor,
                          fontFamily: "AirbnbCereal_W_Bd")),
                )
              ],
            ),
            //SingleChildScrollView(scrollDirection: Axis.horizontal),

            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28),
                    height: 240,
                    width: 152,
                    decoration: BoxDecoration(
                      color: notifire.spleshscreenprimerycolor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(width: 1,color: notifire.topscreenprimerycolor)
                    ),
                    child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: ditails.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16, right: 16),
                              height: 120,
                              width: 120,
                              child: Image.asset("${ditails[index].image1}"),
                            ),
                            Container(
                              margin:
                              EdgeInsets.only(left: 16, right: 16, top: 6),
                              height: 30,
                              width: 120,
                              child: Text(
                                "${ditails[index].name1}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor,
                                    fontSize: 14),
                              ),
                            ),
                            Container(
                              height: 20,
                              width: 120,
                              child: Text(
                                "${ditails[index].name2}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Bk",
                                    color: notifire.mintextscreenprimerycolor,
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 16, top: 16),
                                  height: 30,
                                  width: 56,
                                  child: Text(
                                    "${ditails[index].name3}",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                        notifire.textshscreenprimerycolor,
                                        fontFamily: "AirbnbCereal_W_Md"),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 30),
                                  height: 20,
                                  width: 19,
                                  child: Text(
                                    "/ea",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Bk",
                                        fontSize: 12,
                                        color:
                                        notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Image.asset(
                                    "assets/plus.png",
                                    fit: BoxFit.cover,
                                  ),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 15),
                    height: 240,
                    width: 152,
                    decoration: BoxDecoration(
                      color: notifire.spleshscreenprimerycolor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(width: 1,color: notifire.topscreenprimerycolor)
                    ),
                    child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: ditails.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16, right: 16),
                              height: 120,
                              width: 120,
                              child: Image.asset("${ditails1[index].image1}"),
                            ),
                            Container(
                              margin:
                              EdgeInsets.only(left: 16, right: 16, top: 6),
                              height: 30,
                              width: 120,
                              child: Text(
                                "${ditails1[index].name1}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor,
                                    fontSize: 14),
                              ),
                            ),
                            Container(
                              height: 20,
                              width: 120,
                              child: Text(
                                "${ditails1[index].name2}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Bk",
                                    color: notifire.mintextscreenprimerycolor,
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 16, top: 16),
                                  height: 30,
                                  width: 56,
                                  child: Text(
                                    "${ditails1[index].name3}",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                        notifire.textshscreenprimerycolor,
                                        fontFamily: "AirbnbCereal_W_Md"),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 30),
                                  height: 20,
                                  width: 19,
                                  child: Text(
                                    "/ea",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Bk",
                                        fontSize: 12,
                                        color:
                                        notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Image.asset(
                                    "assets/plus.png",
                                    fit: BoxFit.cover,
                                  ),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 15),
                    height: 240,
                    width: 152,
                    decoration: BoxDecoration(
                      color: notifire.spleshscreenprimerycolor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(width: 1,color: notifire.topscreenprimerycolor)
                    ),
                    child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: ditails.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 16, right: 16),
                              height: 120,
                              width: 120,
                              child: Image.asset("${ditails2[index].image1}"),
                            ),
                            Container(
                              margin:
                              EdgeInsets.only(left: 16, right: 16, top: 6),
                              height: 30,
                              width: 120,
                              child: Text(
                                "${ditails2[index].name1}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Md",
                                    color: notifire.textshscreenprimerycolor,
                                    fontSize: 14),
                              ),
                            ),
                            Container(
                              height: 20,
                              width: 120,
                              child: Text(
                                "${ditails2[index].name2}",
                                style: TextStyle(
                                    fontFamily: "AirbnbCereal_W_Bk",
                                    color: notifire.mintextscreenprimerycolor,
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(left: 16, top: 16),
                                  height: 30,
                                  width: 56,
                                  child: Text(
                                    "${ditails2[index].name3}",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color:
                                        notifire.textshscreenprimerycolor,
                                        fontFamily: "AirbnbCereal_W_Md"),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 30),
                                  height: 20,
                                  width: 19,
                                  child: Text(
                                    "/ea",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Bk",
                                        fontSize: 12,
                                        color:
                                        notifire.mintextscreenprimerycolor),
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  width: 30,
                                  child: Image.asset(
                                    "assets/plus.png",
                                    fit: BoxFit.cover,
                                  ),
                                )
                              ],
                            )
                          ],
                        );
                      },
                    ),
                  )
                ],
              ),
            ),
            Container(height: 30,)
          ],
        ),
      ),
    );
  }
}
class List1 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List1({this.image1, this.name1, this.name2, this.name3});
}

class List2 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List2({this.image1, this.name1, this.name2, this.name3});
}

class List3 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;

  List3({this.image1, this.name1, this.name2, this.name3});
}