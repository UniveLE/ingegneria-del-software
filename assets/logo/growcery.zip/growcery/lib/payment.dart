import 'package:flutter/material.dart';
import 'package:growcery/account.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class payment extends StatefulWidget {
  const payment({Key? key}) : super(key: key);

  @override
  State<payment> createState() => _paymentState();
}

class _paymentState extends State<payment> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: notifire.spleshscreenprimerycolor,
        automaticallyImplyLeading: false,
        elevation: 0,
        toolbarHeight: 50,
        actions: [
          Row(children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return account();
                  },
                ));
              },
              child: Container(
                margin:
                    EdgeInsets.only(top: 8, right: 10, left: 15, bottom: 20),
                height: 8,
                width: 10,
                child: Icon(Icons.arrow_back,
                    size: 20, color: notifire.textshscreenprimerycolor),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 90, right: 110, top: 8, bottom: 10),
              child: Center(
                child: Text(
                  "Payment Options",
                  style: TextStyle(
                      fontSize: 14,
                      color: notifire.textshscreenprimerycolor,
                      fontFamily: "AirbnbCereal_W_Bd"),
                ),
              ),
            ),
          ]),
        ],
      ),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 28, top: 28, bottom: 20),
                  height: 30,
                  width: 65,
                  child: Text("My Card",
                      style: TextStyle(
                          fontSize: 16,
                          fontFamily: "AirbnbCereal_W_Md",
                          color: notifire.textshscreenprimerycolor)),
                ),
                Container(
                  margin:
                      EdgeInsets.only(left: 150, top: 33, right: 28, bottom: 25),
                  height: 20,
                  width: 84,
                  child: Text(
                    "Add New Card",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Bk.otf",
                        color: Color(0xff00AB67),
                        fontSize: 12),
                  ),
                ),
              ],
            ),
            Container(
              height: 200,
              width: 319,
              child: Image.asset("assets/card.png"),
            ),
            Container(
              margin: EdgeInsets.only(top: 66, left: 28, right: 230),
              height: 30,
              width: 109,
              child: Text("Other Method",
                  style: TextStyle(
                      fontSize: 14,
                      color: notifire.textshscreenprimerycolor,
                      fontFamily: "AirbnbCereal_W_Md")),
            ),
            Container(
              height: 80,
              width: 375,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 15, bottom: 15),
                    padding:
                        EdgeInsets.only(left: 14, top: 15, bottom: 16, right: 13),
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        color: Color(0xff00AB67).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16)),
                    child: Image.asset("assets/logo/cash.png"),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 16,top: 25,bottom: 25,right: 145),
                    height: 30,
                    width: 117,
                    child: Center(
                      child: Text(
                        "Cash On Delivery",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              height: 80,
              width: 375,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 15, bottom: 15),
                    padding:
                    EdgeInsets.only(left: 14, top: 15, bottom: 16, right: 13),
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        color: Color(0xff0067FF).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16)),
                    child: Image.asset("assets/logo/payal.png"),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 25,bottom: 25,right: 200,left: 16),
                    height: 30,
                    width: 46,
                    child: Center(
                      child: Text(
                        "Paypal",
                        style: TextStyle(
                            fontFamily: "AirbnbCereal_W_Md",
                            color: notifire.textshscreenprimerycolor,
                            fontSize: 14),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
