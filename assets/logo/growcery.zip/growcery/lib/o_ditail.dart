import 'package:another_stepper/another_stepper.dart';
import 'package:enhance_stepper/enhance_stepper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:growcery/order.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class o_ditail extends StatefulWidget {
  List ids;
  o_ditail(this.ids);

  @override
  State<o_ditail> createState() => _o_ditailState();
}

class _o_ditailState extends State<o_ditail> {
  List<List1> ditails = [
    List1(
        image1: "assets/cabbage.png",
        name1: "Cabbage",
        name2: "Approx 6oz",
        name3: "\$3.49",
        name4: "\$5.98"),
    List1(
        image1: "assets/orrange.png",
        name1: "Mandarin",
        name2: "4ct, approx 2lb",
        name3: "\$2.99",
        name4: "\$5.98"),
    List1(
        image1: "assets/stew.png",
        name1: "Beef Chuck Stew",
        name2: "12-14ct/lb",
        name3: "\$7.99",
        name4: "\$15.98"),
  ];
  List<StepperData> Stepperdata = [
    StepperData(
      iconWidget: Container(
        padding: EdgeInsets.all(5),
        height: 30,
        width: 30,
        decoration: BoxDecoration(
            color: Color(0xffFF3B3B).withOpacity(0.1),
            borderRadius: BorderRadius.circular(15)),
        child: Icon(Icons.check_outlined, color: Color(0xffFF3B3B)),
      ),
      title: StepperText("Order Confirmed",
          textStyle: TextStyle(
              color: Colors.black87,
              fontFamily: "AirbnbCereal_W_Md",
              fontSize: 14)),
      subtitle: StepperText(
          "Sep 29, 2021                                                            08.00 PM",
          textStyle: TextStyle(
              color: Colors.black45,
              fontSize: 12,
              fontFamily: "AirbnbCereal_W_Bk.otf")),
    ),
    StepperData(
        iconWidget: Container(
          padding: EdgeInsets.all(5),
          height: 30,
          width: 30,
          decoration: BoxDecoration(
              color: Color(0xffFFC62B).withOpacity(0.1),
              borderRadius: BorderRadius.circular(15)),
          child: Image.asset(
            "assets/logo/i_1.png",
            color: Color(0xffFFC62B),
            fit: BoxFit.cover,
            height: 10,
            width: 10,
          ),
        ),
        title: StepperText("Order on Process",
            textStyle: TextStyle(
                color: Colors.black87,
                fontFamily: "AirbnbCereal_W_Md",
                fontSize: 14)),
        subtitle: StepperText(
            "Sep 30, 2021                                                            07.00 AM",
            textStyle: TextStyle(
                color: Colors.black45,
                fontSize: 12,
                fontFamily: "AirbnbCereal_W_Bk.otf"))),
    StepperData(
        iconWidget: Container(
            padding: EdgeInsets.all(5),
            height: 30,
            width: 30,
            decoration: BoxDecoration(
                color: Color(0xff00AB67).withOpacity(0.1),
                borderRadius: BorderRadius.circular(15)),
            child:
                Image.asset("assets/logo/i_2.png", color: Color(0xff00AB67))),
        title: StepperText("Order Shipped",
            textStyle: TextStyle(
                color: Colors.black87,
                fontFamily: "AirbnbCereal_W_Md",
                fontSize: 14)),
        subtitle: StepperText(
            "Sep 30, 2021                                                            07.30 PM",
            textStyle: TextStyle(
                color: Colors.black45,
                fontSize: 12,
                fontFamily: "AirbnbCereal_W_Bk.otf"))),
    StepperData(
        iconWidget: Container(
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
                color: Color(0xff0067FF).withOpacity(0.1),
                borderRadius: BorderRadius.circular(15)),
            child:
                Image.asset("assets/logo/i_3.png", color: Color(0xff0067FF))),
        title: StepperText("Order Delivered",
            textStyle: TextStyle(
                color: Colors.black87,
                fontFamily: "AirbnbCereal_W_Md",
                fontSize: 14)),
        subtitle: StepperText(
            "Sep 30, 2021                                                             08.00 AM",
            textStyle: TextStyle(
                color: Colors.black45,
                fontSize: 12,
                fontFamily: "AirbnbCereal_W_Bk.otf")))
  ];
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
        appBar: AppBar(
          backgroundColor: notifire.spleshscreenprimerycolor,
          automaticallyImplyLeading: false,
          elevation: 0,
          toolbarHeight: 50,
          actions: [
            Row(children: [
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return order();
                    },
                  ));
                },
                child: Container(
                  margin:
                      EdgeInsets.only(top: 8, left: 20, right: 10, bottom: 20),
                  height: 8,
                  width: 10,
                  child: Icon(Icons.arrow_back,
                      size: 20, color: notifire.textshscreenprimerycolor),
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 140, top: 8, left: 90,bottom: 10),
                child: Center(
                  child: Text(
                    "Order Detail",
                    style: TextStyle(
                        fontSize: 14,
                        color: notifire.textshscreenprimerycolor,
                        fontFamily: "AirbnbCereal_W_Bd"),
                  ),
                ),
              ),
            ]),
          ],
        ),
        bottomNavigationBar: Container(

          margin: EdgeInsets.only(
              left: 28, right: 28, bottom: 8, top: 18),
          height: 50,
          width: 80,
          decoration: BoxDecoration(
              color: Color(0xff00AB67),
              borderRadius: BorderRadius.circular(20)),
          child: Center(
              child: Text(
                "Write Feedback",
                style: TextStyle(
                    fontSize: 14,
                    fontFamily: "AirbnbCereal_W_Md",
                    color: notifire.textshscreenprimerycolor),
              )),
        ),
         backgroundColor: notifire.spleshscreenprimerycolor,
        body: SingleChildScrollView(
          child: Column(children: [
            Container(
              margin: EdgeInsets.only(left: 28, top: 28),
              height: 30,
              width: 250,
              child: Text(
                "Order ID ${widget.ids}",
                style: TextStyle(
                    fontSize: 16,
                    color: notifire.textshscreenprimerycolor,
                    fontFamily: "AirbnbCereal_W_Bd"),
              ),
            ),
            // Container(
            //   child: Stepper(
            //     steps: [
            //       Step(
            //           title: SizedBox(child: ListTile(leading: Icon(Icons.payment),title: Text("order"),subtitle: Text("5484nddcbu"),),),content: Container()),
            //       Step(
            //           title: Text(
            //             "Order Confirmed",
            //             style: TextStyle(
            //                 fontFamily: "AirbnbCereal_W_Md.otf",
            //                 color: notifire.textshscreenprimerycolor,
            //                 fontSize: 14),
            //           ),
            //           content: Container(),
            //           subtitle: Text("Sep 29, 2021"),
            //           isActive: false)
            //     ],
            //   ),
            // ),
            Container(
              color: Colors.white,
              child: Column(
                children: [
                  AnotherStepper(
                      stepperList: Stepperdata,
                      stepperDirection: Axis.vertical,
                      iconHeight: 30,
                      iconWidth: 30,
                      gap: 20,
                      activeBarColor: notifire.mintextscreenprimerycolor,
                      activeIndex: 4),
                  // AnotherStepper(
                  //   stepperList: Stepperdata, stepperDirection: Axis.vertical,iconHeight: 30,iconWidth: 30,)
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 30),
              height: 10,
              width: MediaQuery.of(context).size.width,
              color: notifire.topscreenprimerycolor,
            ),
            Container(
              margin: EdgeInsets.only(left: 28, top: 28, right: 230),
              height: 30,
              width: 120,
              child: Text(
                "Order Detail",
                style: TextStyle(fontFamily: "AirbnbCereal_W_Bd", fontSize: 16),
              ),
            ),
            Container(
              height: 430,
              width: double.infinity,
              child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: ditails.length,
                  itemBuilder: (context, index) {
                    return Container(
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  width: 2,
                                  color: notifire.topscreenprimerycolor))),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(top: 14, left: 28),
                                height: 50,
                                width: 50,
                                child: Image.asset("${ditails[index].image1}"),
                              ),
                              Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(
                                        top: 14, left: 16, right: 20),
                                    height: 20,
                                    width: 120,
                                    child: Text(
                                      "${ditails[index].name1}",
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontFamily: "AirbnbCereal_W_Md.otf",
                                          color: notifire
                                              .textshscreenprimerycolor),
                                    ),
                                  ),
                                  Container(
                                    margin:
                                        EdgeInsets.only(left: 16, right: 50),
                                    height: 15,
                                    width: 90,
                                    child: Text(
                                      "${ditails[index].name2}",
                                      style: TextStyle(
                                          color: notifire
                                              .mintextscreenprimerycolor,
                                          fontFamily: "AirbnbCereal_W_Bk",
                                          fontSize: 12),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(left: 30, top: 14),
                                    height: 30,
                                    width: 45,
                                    child: Text(
                                      "${ditails[index].name3}",
                                      style: TextStyle(
                                          fontSize: 16,
                                          color:
                                              notifire.textshscreenprimerycolor,
                                          fontFamily: "AirbnbCereal_W_Md"),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.only(right: 30),
                                    height: 20,
                                    width: 19,
                                    child: Text(
                                      "/ea",
                                      style: TextStyle(
                                          fontFamily: "AirbnbCereal_W_Bk",
                                          fontSize: 12,
                                          color: notifire
                                              .mintextscreenprimerycolor),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(
                                    left: 28, top: 21, bottom: 14),
                                height: 30,
                                width: 35,
                                child: Text("Total:"),
                              ),
                              Container(
                                margin: EdgeInsets.only(
                                    top: 9, left: 5, bottom: 14),
                                height: 15,
                                width: 45,
                                child: Text("${ditails[index].name4}",
                                    style: TextStyle(
                                        fontFamily: "AirbnbCereal_W_Md",
                                        fontSize: 12,
                                        color:
                                            notifire.textshscreenprimerycolor)),
                              ),
                              Container(
                                margin: EdgeInsets.only(
                                    left: 140, right: 20, bottom: 8, top: 18),
                                height: 30,
                                width: 80,
                                decoration: BoxDecoration(
                                    color: Color(0xff00AB67),
                                    borderRadius: BorderRadius.circular(8)),
                                child: Center(
                                    child: Text(
                                  "Buy Again",
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontFamily: "AirbnbCereal_W_Md",
                                      color: notifire.textshscreenprimerycolor),
                                )),
                              )
                            ],
                          )
                        ],
                      ),
                    );
                  }),
            ),
            Container(
              margin: EdgeInsets.only(top: 30),
              height: 10,
              width: MediaQuery.of(context).size.width,
              color: notifire.topscreenprimerycolor,
            ),
            Container(
              height: 50,
              width: 370,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 10, bottom: 10),
                    child: Text(
                      "Total Amount",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          color: notifire.textshscreenprimerycolor,
                          fontSize: 14),
                    ),
                  ),
                  Container(margin: EdgeInsets.only(top: 10,bottom: 10,left: 150),
                    child: Text("\$25.45",
                        style: TextStyle(
                            fontSize: 12,
                            color: notifire.mintextscreenprimerycolor,
                            fontFamily: "AirbnbCereal_W_Bk")),
                  )
                ],
              ),
            ),
            Container(
              height: 50,
              width: 370,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 28, top: 10, bottom: 10),
                    child: Text(
                      "Payment Method",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          color: notifire.textshscreenprimerycolor,
                          fontSize: 14),
                    ),
                  ),
                  Container(margin: EdgeInsets.only(top: 10,bottom: 10,left: 128),
                    child: Text("Credit Card",
                        style: TextStyle(
                            fontSize: 12,
                            color: notifire.mintextscreenprimerycolor,
                            fontFamily: "AirbnbCereal_W_Bk")),
                  )
                ],
              ),

            )
          ]),
        ));
  }
}

class List1 {
  String? image1;
  String? name1;
  String? name2;
  String? name3;
  String? name4;

  List1({this.image1, this.name1, this.name2, this.name3, this.name4});
}
