import 'package:flutter/material.dart';
import 'package:growcery/account.dart';
import 'package:growcery/profile.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class password extends StatefulWidget {
  const password({Key? key}) : super(key: key);

  @override
  State<password> createState() => _passwordState();
}

class _passwordState extends State<password> {
  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: notifire.spleshscreenprimerycolor,
        automaticallyImplyLeading: false,
        elevation: 0,
        toolbarHeight: 50,
        actions: [
          Row(children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return profile();
                  },
                ));
              },
              child: Container(
                margin:
                    EdgeInsets.only(top: 8, right: 10, left: 15, bottom: 20),
                height: 8,
                width: 10,
                child: Icon(Icons.arrow_back,
                    size: 20, color: notifire.textshscreenprimerycolor),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 80, right: 120, top: 8, bottom: 10),
              child: Center(
                child: Text(
                  "Change Password",
                  style: TextStyle(
                      fontSize: 14,
                      color: notifire.textshscreenprimerycolor,
                      fontFamily: "AirbnbCereal_W_Bd"),
                ),
              ),
            ),
          ]),
        ],
      ),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(left: 28,right:28 ,top: 16),
              height: 90,
              width: 319,
              child: Text(
                  "Password Must contain at least 8 characters. With uppercase, lowercase, and special characters.",
              style: TextStyle(fontSize: 14,fontFamily: "AirbnbCereal_W_Md",color: notifire.mintextscreenprimerycolor),),
            ),
            Container(
              margin: EdgeInsets.only(right: 120,top: 28),
              width: 200,
              child: Text(
                "Old Password",
                style: TextStyle(
                    fontSize: 12,
                    color: notifire.mintextscreenprimerycolor,
                    fontFamily: "AirbnbCereal_W_Bd"),
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 12),
                height: 60,
                width: 319,
                decoration: BoxDecoration(
                  color: Color(0xffFAFAFA),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Icon(Icons.lock_outline,color: notifire.mintextscreenprimerycolor,)),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 48,
                      width: 230,
                      child: TextField(
                        obscureText: true,
                        decoration: InputDecoration(
                          disabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          hintText: "password",
                          //  labelText: "user name"
                        ),
                      ),
                    ),
                    Container(height: 10,width: 18,child: Image.asset("assets/logo/pass.png"),)
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(right: 120,top: 28),
              width: 200,
              child: Text(
                "New Password",
                style: TextStyle(
                    fontSize: 12,
                    color: notifire.mintextscreenprimerycolor,
                    fontFamily: "AirbnbCereal_W_Bd"),
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 12,bottom: 285),
                height: 60,
                width: 319,
                decoration: BoxDecoration(
                  color: Color(0xffFAFAFA),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Icon(Icons.lock_outline,color: notifire.mintextscreenprimerycolor,)),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 48,
                      width: 230,
                      child: TextField(
                        obscureText: true,
                        decoration: InputDecoration(
                          disabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          hintText: "password",
                          //  labelText: "user name"
                        ),
                      ),
                    ),
                    Container(height: 10,width: 18,child: Image.asset("assets/logo/pass.png"),)
                  ],
                ),
              ),
            ),
            InkWell(onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return account();
              },));
            },
              child: Container(
              //  margin: EdgeInsets.only(top: 285),
                height: 60,
                width: 319,
                decoration: BoxDecoration( color: Color(0xff00AB67),borderRadius: BorderRadius.circular(20)),
                child: Center(
                  child: Text(
                    "Change Password",
                    style: TextStyle(
                        color: Colors.white,
                        fontFamily: "AirbnbCereal_W_Bk",
                        fontSize: 14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
