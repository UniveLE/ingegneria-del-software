import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:growcery/account.dart';
import 'package:growcery/all_o.dart';
import 'package:growcery/cart.dart';
import 'package:growcery/favurite.dart';
import 'package:growcery/home.dart';
import 'package:growcery/notification.dart';
import 'package:growcery/o_ditail.dart';
import 'package:growcery/press.dart';
import 'package:growcery/previous.dart';
import 'package:growcery/search.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class order extends StatefulWidget {
  const order({Key? key}) : super(key: key);

  @override
  State<order> createState() => _orderState();
}

class _orderState extends State<order> with TickerProviderStateMixin {
//   List5(),
// List5(),
// List5()

  late TabController _controller;
  late Colornotifire notifire;

  void initState() {
    super.initState();
    _controller = TabController(length: 3, vsync: this);
    _controller.addListener(() {
      setState(() {});
    });
  }

  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  List<Widget> ord = const [all_o(),
  press(),
    previous()
  ];

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
      bottomNavigationBar: Container(
        height: 80,
        width: 380,
        child: Row(
          children: [
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return home();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 33, top: 18, right: 31),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/home1.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 25, top: 7, left: 25),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Home",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 35, top: 18, right: 38),
                  height: 18,
                  width: 18,
                  child: Image.asset("assets/logo/order.png",
                      color: Color(0xff00AB67)),
                ),
                Container(
                  margin: EdgeInsets.only(top: 7, left: 21, right: 20),
                  height: 12,
                  width: 35,
                  child: Text(
                    "Order",
                    style: TextStyle(
                        fontFamily: "AirbnbCereal_W_Md",
                        fontSize: 12,
                        color: Color(0xff00AB67)),
                  ),
                )
              ],
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return cart();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 18, left: 30, right: 30),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/cart.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 12, top: 7),
                    height: 12,
                    width: 35,
                    child: Text(
                      "Cart",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return account();
                  },
                ));
              },
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 18, left: 35, right: 20),
                    height: 18,
                    width: 18,
                    child: Image.asset(
                      "assets/logo/account1.png",
                      color: notifire.mintextscreenprimerycolor,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 35, top: 7, right: 20),
                    height: 12,
                    width: 50,
                    child: Text(
                      "Account",
                      style: TextStyle(
                          fontFamily: "AirbnbCereal_W_Md",
                          fontSize: 12,
                          color: notifire.textshscreenprimerycolor),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: notifire.spleshscreenprimerycolor,
        elevation: 0,
        toolbarHeight: 114,
        actions: [
          Column(children: [
            Row(children: [
              Center(
                child: Container(
                  margin: EdgeInsets.only(right: 118, left: 28),
                  height: 40,
                  width: 120,
                  child: Text("My Order",
                      style: TextStyle(
                          color: notifire.textshscreenprimerycolor,
                          fontFamily: "AirbnbCereal_W_Bd",
                          fontSize: 24)),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return favurite();
                    },
                  ));
                },
                child: Container(
                  height: 18,
                  width: 18,
                  child: Image.asset(
                    "assets/logo/like.png",
                    color: notifire.textshscreenprimerycolor,
                  ),
                ),
              ),
              Center(
                child: Container(
                  margin:
                      EdgeInsets.only(top: 5, left: 20, bottom: 4, right: 28),
                  //    color: notifire.spleshscreenprimerycolor,
                  child: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return notification();
                        },
                      ));
                    },
                    child: Stack(children: [
                      Container(
                        margin: EdgeInsets.only(top: 3),
                        height: 17,
                        width: 16,
                        child: Image.asset(
                          "assets/logo/notification.png",
                          color: notifire.textshscreenprimerycolor,
                          width: 17,
                          height: 16,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 8, bottom: 10),
                        height: 12,
                        width: 12,
                        child: Image.asset("assets/Badge.png"),
                      )
                    ]),
                  ),
                ),
              ),
            ]),
            Container(
              width: MediaQuery.of(context).size.width * 1,
              child: TabBar(controller: _controller, tabs: [
                Tab(
                  child: Text("All",
                      style: TextStyle(
                          fontSize: 14,
                          color: notifire.textshscreenprimerycolor)),
                ),
                Tab(
                  child: Text("On Process",
                      style: TextStyle(
                          color: notifire.textshscreenprimerycolor,
                          fontSize: 14)),
                ),
                Tab(
                  child: Text("Previous",
                      style: TextStyle(
                          color: notifire.textshscreenprimerycolor,
                          fontSize: 14)),
                )
              ]),
            )
          ]),
        ],
      ),
      backgroundColor: notifire.spleshscreenprimerycolor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: MediaQuery.of(context).size.height,
              child: TabBarView(controller: _controller, children: ord),
            ),
          ],
        ),
      ),
    );
  }
}
