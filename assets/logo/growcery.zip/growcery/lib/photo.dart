import 'package:flutter/material.dart';
import 'package:growcery/detail.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class photo extends StatefulWidget {
  List ditails;
  var index;
  List<String> slide;

  photo(this.ditails, this.index, this.slide);

  @override
  State<photo> createState() => _photoState();
}

class _photoState extends State<photo> {
  int currentIndex = 0;
  late PageController _controller;

  @override
  void initState() {
    _controller = PageController(initialPage: 0);
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  late Colornotifire notifire;

  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }

  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return Scaffold(
        appBar: AppBar(
          backgroundColor: notifire.spleshscreenprimerycolor,
          automaticallyImplyLeading: false,
          elevation: 0,
          toolbarHeight: 50,
          actions: [
            Row(children: [
              InkWell(
               onTap: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context) {
                   return detail(widget.ditails,widget.index, widget.slide);
                 },));
               },
                child: Container(
                  margin:
                  EdgeInsets.only(top: 8, left: 20, right: 10, bottom: 20),
                  height: 8,
                  width: 10,
                  child:
                  Icon(Icons.arrow_back, size: 20, color: notifire.textshscreenprimerycolor),
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 150, left: 100,top: 8, bottom: 10),
                child: Center(
                  child: Text(
                    "All Images",
                    style: TextStyle(
                        fontSize: 14,
                        color: notifire.textshscreenprimerycolor,
                        fontFamily: "AirbnbCereal_W_Bd"),
                  ),
                ),
              ),

            ]),
          ],
        ),
      backgroundColor: notifire.spleshscreenprimerycolor,
        body: SingleChildScrollView(
          child: Column(children: [
      Center(
          child: Container(
            margin: EdgeInsets.only(top: 200),
              height: 319,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(

                // color: Color(0xffF2FBF7),
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
              child: PageView.builder(
                  controller: _controller,
                  itemCount: widget.slide.length,
                  onPageChanged: (int index) {
                    setState(() {
                      currentIndex = index;
                    });
                  },
                  itemBuilder: (_, i) {
                    return Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 40, right: 20),
                              height: 270,
                              width: 270,
                              //color: Colors.blueAccent,
                              child: Image.asset(
                                  "${widget.ditails[widget.index].image1}"),
                            ),
                          ],
                        ),
                      ],
                    );
                  })),
      ),
      SizedBox(height: 140,),
      Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            widget.slide.length,
            (index) => buildDot(index, context),
          ),
      ),
    ]),
        ));
  }

  Container buildDot(int index, BuildContext context) {
    return Container(
        height: 6,
        width: currentIndex == index ? 25 : 8,
        margin: const EdgeInsets.only(right: 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: (index == currentIndex)
                ? Colors.blueAccent
                : Colors.grey.withOpacity(0.2)));
  }
}
