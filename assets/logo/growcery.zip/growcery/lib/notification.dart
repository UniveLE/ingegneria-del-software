import 'package:clipboard/clipboard.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:growcery/home.dart';
import 'package:growcery/theme/theme_manager.dart';
import 'package:growcery/transection.dart';
import 'package:growcery/update.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';

class notification extends StatefulWidget {
  const notification({Key? key}) : super(key: key);

  @override
  State<notification> createState() => _notificationState();
}

class _notificationState extends State<notification> with TickerProviderStateMixin{
   late TabController _controller;
  late Colornotifire notifire;
  void initState(){
    super.initState();
    _controller = TabController(length: 2, vsync: this);
    _controller.addListener(() {setState(() {

    });});
  }
  void dispose(){
    super.dispose();
    _controller.dispose();
  }
  List<Widget> noti = const[
    update(),
transection(),
  ];
  getdarkmodepreviousstate() async {
    final prefs = await SharedPreferences.getInstance();
    bool? previusstate = prefs.getBool("setIsDark");
    if (previusstate == null) {
      notifire.setlsDark = false;
    } else {
      notifire.setlsDark = previusstate;
    }
  }
  @override
  Widget build(BuildContext context) {
    notifire = Provider.of<Colornotifire>(context, listen: true);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: notifire.spleshscreenprimerycolor,
          automaticallyImplyLeading: false,
          toolbarHeight: 112,
          elevation: 0,
          actions: [
            Column(children: [
              Row(children: [
                SizedBox(width: 10,),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return home();
                      },
                    ));
                  },
                  child:
              Container(
                    margin: EdgeInsets.only(top: 8,bottom: 10),
                    height: 10,
                    child:    Icon(Icons.arrow_back,
                        size: 20, color: notifire.textshscreenprimerycolor),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(right: 100,left: 100, top: 20),
                  child: Center(
                    child: Text(
                      "Notifications",
                      style: TextStyle(
                          fontSize: 14,
                          color: notifire.textshscreenprimerycolor,
                          fontFamily: "AirbnbCereal_W_Bd"),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(
                    right: 20,
                    top: 20,
                  ),
                  height: 18,
                  width: 15,
                  child: Image.asset("assets/logo/setting.png",
                      color: notifire.textshscreenprimerycolor),
                ),
              ]),
              SizedBox(height: 26,),
              Container(width: MediaQuery.of(context).size.width*1,
                child: TabBar(controller: _controller,tabs: [
                  Tab(
                    child: Text("Update",
                        style: TextStyle(fontSize: 14, color: notifire.textshscreenprimerycolor)),
                  ),
                  Tab(
                    child: Text("Transactions",
                        style: TextStyle(color: notifire.textshscreenprimerycolor, fontSize: 14)),
                  )
                ]),
              )
            ]),
          ],
        ),
        backgroundColor: notifire.spleshscreenprimerycolor,
        body: SingleChildScrollView(
          child:
              Container(width: double.infinity,height: MediaQuery.of(context).size.height,
                child: TabBarView(controller: _controller,children:
                 noti
                ),
              ),
        ),
      ),
    );
  }
}
